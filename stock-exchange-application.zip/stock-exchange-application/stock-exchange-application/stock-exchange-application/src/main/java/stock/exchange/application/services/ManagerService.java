package stock.exchange.application.services;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import stock.exchange.application.exceptions.BadResourceException;
import stock.exchange.application.exceptions.InvalidOperation;
import stock.exchange.application.exceptions.ResourceNotFoundException;
import stock.exchange.application.models.Investor;
import stock.exchange.application.models.Manager;
import stock.exchange.application.models.Stock;
import stock.exchange.application.repositories.ManagerRepository;





@Service
public class ManagerService  {
	@Autowired
	ManagerRepository managerRepository;
	
	private boolean existsById(int companyId) {
        return managerRepository.existsById(companyId);
    }

	 public Manager addManagerInfo(Manager info) throws BadResourceException, ResourceNotFoundException {
		 if (!StringUtils.isEmpty(info.getManagerName())) {
			   if ( existsById(info.getManagerId())) {
			          throw new ResourceNotFoundException("Company  with id: " + info.getManagerId()+ "already exists");//throws exception if already stockId exists
			   }
			   return  managerRepository.save(info);//save is used to insert the records in the table
		 }
		 else {
			     BadResourceException exc = new BadResourceException("Failed to save manager details");
			     exc.addErrorMessage("Company is null or empty");
			     throw exc;
		 }
	 }
		 
//		public Manager addManagerInfo(Manager info)
//		{
//			try
//			{
//				if( (Validations.name(info.getManagerName())) && 
//				   (Validations.email(info.getEmail())) && (Validations.mobileNo(info.getMobileNo())))
//				  
//					return managerRepository.save(info);
//				else
//					throw new InvalidOperation("Manager details are not valid");
//			}
//			catch(InvalidOperation e) 
//			{
//				System.out.println(e);
//			}
//			return null;
//		}
		
		public List<Manager> getAllManagerInfo() 
		{
			return managerRepository.findAll();
		}
		
//		public Manager getManagerDetails(int managerId)
//		{
//			Optional<Manager> manager = managerRepository.findById(managerId);
//			try
//			{
//				if(manager.isPresent())
//					return manager.get();
//				else
//					throw new InvalidOperation("No Manager found with given id");
//			}
//			catch(InvalidOperation e)
//			{
//				System.out.println(e);
//			}
//			return null;
//		}
		
		public Manager getManagerDetails(int managerId) throws ResourceNotFoundException {
			Optional<Manager> manager = managerRepository.findById(managerId);
			if(manager.isPresent())
				return manager.get();
			else
				throw new ResourceNotFoundException("Manager details not found with the given id. Please enter a valid investor id");
		}
		
		public Manager updateManagerInfo(int managerId,Manager info) throws BadResourceException, ResourceNotFoundException {
			Optional<Manager> mg = managerRepository.findById(managerId);

	        if (mg.isPresent()) {
	        	/*Manager updatemg=mg.get();
	        	updatemg.setManagerName(info.getManagerName());
	        	updatemg.setEmail(info.getEmail());
	        	updatemg.setMobileNo(info.getMobileNo());*/
	        	return managerRepository.save(info);
		      }
		      else
		      {
					BadResourceException exc = new BadResourceException("No company present with the given Id to Update...");
				     exc.addErrorMessage("Stock is null or empty");
				     throw exc;
		      }
		}  

			/*if (!StringUtils.isEmpty(info.getManagerName())) {
			    if (!existsById(info.getManagerId())) {
			           throw new ResourceNotFoundException("Cannot find manager with id: " + info.getManagerId());//throws exception if stockId can't find
			    }
			        return  managerRepository.save(info);//save is used to update the records in the table
		    }
		    else {
			     BadResourceException exc = new BadResourceException("Failed to save Stock details");
			     exc.addErrorMessage("Stock is null or empty");
			     throw exc;
			}*/
		

		/*public ElectionOfficer updateElectionOfficerDetails(int officerId, ElectionOfficer officer) throws ElectionOfficerNotFoundException
	    {

		      Optional<ElectionOfficer> repOfficer = elRepo.findById(officerId);

		        if (repOfficer.isPresent()) {

			    ElectionOfficer officerToBeUpdated = repOfficer.get();
			    officerToBeUpdated.setFirstName(officer.getFirstName());
			    officerToBeUpdated.setLastName(officer.getLastName());
			    officerToBeUpdated.setPassword(officer.getPassword());
			 
			    return elRepo.save(officerToBeUpdated);
		      }
		      else
		      {
					throw new ElectionOfficerNotFoundException("No Officer present with the given Id to Update...Please enter valid Id to update");

		      }
	      }*/
//		public Manager updateManagerInfo(Manager info) 
//		{
//			try
//			{
//				if( (Validations.name(info.getManagerName())) && 
//				   (Validations.email(info.getEmail())) && (Validations.mobileNo(info.getMobileNo())))
//				   
//					return managerRepository.save(info);
//				else
//					throw new InvalidOperation("Manager details are not valid");
//			}
//			catch(InvalidOperation e)
//			{
//				System.out.println(e);
//			}
//			return null;
//		}

		public Manager deleteManagerInfo(int managerId) 
		{
			Optional<Manager> manager = managerRepository.findById(managerId);
			try
			{
				if(manager.isPresent())
				{
					managerRepository.deleteById(managerId);
					return manager.get();
				}
				else
					throw new InvalidOperation("No Manager found with given id");
			}
			catch(InvalidOperation e)
			{
			System.out.println(e);
		    }
			return manager.get();
		}
		
		/*public Manager deleteManagerInfo(int managerId) throws ResourceNotFoundException {
			   
			 Optional<Manager> manager=managerRepository.findById(managerId);
			 if (!existsById(managerId)) { 
		         throw new ResourceNotFoundException("Cannot find manager with id: " + managerId);//throws exception if stockId can't find
		     }
			 else {
			    	return managerRepository.deleteById(managerId); //deleteById Query written in StockRepository class
			 }
			                
	    }*/
	
		
		
	}

