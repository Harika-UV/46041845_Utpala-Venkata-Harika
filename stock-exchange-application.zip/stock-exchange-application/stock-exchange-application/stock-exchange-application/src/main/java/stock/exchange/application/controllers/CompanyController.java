package stock.exchange.application.controllers;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import stock.exchange.application.exceptions.BadResourceException;
import stock.exchange.application.exceptions.InvalidOperation;
import stock.exchange.application.exceptions.ResourceNotFoundException;
import stock.exchange.application.models.Company;
import stock.exchange.application.services.CompanyService;

@CrossOrigin(origins="http://localhost:3000")
@RestController
@RequestMapping("/comp/")
public class CompanyController
{
	Logger logger = LoggerFactory.getLogger(CompanyController.class);
	
	@Autowired
	CompanyService compService;
	
	@PostMapping("/companies")
	public @ResponseBody Company addCompanyInfo(@RequestBody Company info) throws BadResourceException, ResourceNotFoundException 
	{
		logger.info("add company info initialized");
		return compService.addCompanyInfo(info);
	}
	
	@GetMapping("/companies")
	public @ResponseBody List<Company> getAllCompanyInfo() 
	{ 
		logger.info("get all company info initialized");
		return compService.getAllCompanyInfo();
	}
	
	@GetMapping("/companies/{companyId}")
	public @ResponseBody Company getCompanyDetails(@PathVariable int companyId)
	{
		logger.info("get company details based on id initialized");
		return compService.getCompanyDetails(companyId);
	}
	
	@PutMapping("/companies/{companyId}")
	public @ResponseBody Company updateCompanyInfo(@PathVariable int companyId,@RequestBody Company info) throws ResourceNotFoundException, BadResourceException
	{
		logger.info("update company info initialized");
		
			return compService.updateCompanyInfo(companyId,info);
	}
	
	@DeleteMapping("/companies/{companyId}")
	public @ResponseBody Company deleteCompanyInfo(@PathVariable int companyId) throws ResourceNotFoundException 
	{
		logger.info("delete company info initialized");
		return compService.deleteCompanyInfo(companyId);
	}
	
}