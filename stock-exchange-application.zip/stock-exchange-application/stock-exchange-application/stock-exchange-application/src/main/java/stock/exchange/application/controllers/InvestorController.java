package stock.exchange.application.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import stock.exchange.application.exceptions.BadResourceException;
import stock.exchange.application.exceptions.ResourceNotFoundException;
import stock.exchange.application.models.Investor;
import stock.exchange.application.services.InvestorService;


@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/inv/")
public class InvestorController {

	@Autowired
	private InvestorService investorService;
	
	@GetMapping("/investors")
	public @ResponseBody List<Investor> getAllInvestors() {
		return investorService.getAllInvestors();	
	}
	
	@GetMapping("/investors/{investorId}")
	public @ResponseBody Investor getInvestorDetails(@PathVariable int investorId) throws ResourceNotFoundException {
		return investorService.getInvestorDetails(investorId);
	}
	
	@PostMapping("/investors")
	public @ResponseBody Investor addInvestor(@RequestBody Investor investor) throws ResourceNotFoundException, BadResourceException {
		return investorService.addInvestor(investor);
	}
	
	@PutMapping("/investors")
	public @ResponseBody Investor updateInvestor(@RequestBody Investor info) throws ResourceNotFoundException, BadResourceException {
		return investorService.updateInvestor(info);
	}
	
	@DeleteMapping("/investors/{investorId}")
	public @ResponseBody Investor deleteInvestor(@PathVariable  int investorId) throws ResourceNotFoundException {
		return investorService.deleteInvestor(investorId);
	}
	
	/*@GetMapping("/{companyName}")
	public @ResponseBody List<Investor> viewAllInvestorCompany(@PathVariable("companyName") String companyName) {
		return investorService.viewAllInvestorCompany(companyName);
	}*/
	
//	@GetMapping("/{stockName}")
//	public @ResponseBody List<Investor> viewAllInvestorStock(@PathVariable("stockName") String stockName) {
//		return investorService.viewAllInvestorStock(stockName);
//	}
}

