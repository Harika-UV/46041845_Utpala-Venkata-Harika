package stock.exchange.application.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

@Entity  
@Table(name="user_info")
public class User {
	@Id
	@GeneratedValue
	private int id;
	@NotBlank(message="User Name should not be null")
	private String userName; 
	@Pattern(regexp="[A-Za-z]{1,}[0-9]{1,}{5,}",message="Please provide valid adminPassword")
	private String password;
	//private String role;
	
	public User() { //zero-parameterized constructor
		super();
	}
	
	public User(int id, String userName,String password) {
		super();
		this.id = id;
		this.userName = userName;
		this.password = password;
	}

	public User(String userName, String password) {
		super();
		this.userName = userName;
		this.password = password;
	}

	/*public User(String userName, String password, String role) {
		super();
		this.userName = userName;
		this.password = password;
		this.role = role;
	}*/
	
	
	public String getUserName() {
		return userName;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	/*public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}*/

	@Override
	public String toString() {
		return "User [userName=" + userName + ", userPassword=" + password +"]";
				 
	}

}

