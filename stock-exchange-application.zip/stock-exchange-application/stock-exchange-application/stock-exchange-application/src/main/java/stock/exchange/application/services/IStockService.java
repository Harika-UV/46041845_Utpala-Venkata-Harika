package stock.exchange.application.services;


import java.util.List;

import stock.exchange.application.models.Stock;

/**
 * 
 * @author jhansi
 *
 */

public interface IStockService {//By default all the methods present in interface are public abstract
	
	
	//------------------------------STOCK MODULE-------------------------------------
			/***********************
			 * 
			 * 
			 * 
			 * Function Name	:	exitsById
			 - Input Parameters	:	int stockId
			 - Return Type		: 	boolean
			 - Author			:	Jhansi
			 - Creation Date    :   12/11/2020
			 - Description		:	This method checks that stockId is present or not.
			 						If it exits returns true otherwise it returns false
			  *
			  *
			  *
			*****************************/
	
	public boolean existsById(int stockId);
	
//	*************************************************
	
	
	//-------------------------------STOCK MODULE--------------------------------------
		/**************************
		 * 
		 * 
		 * 
		 * Function Name	:	addStockDetails
		 - Input Parameters	:	stock object
		 - Return Type		:   Stock stock
		 - Throws           :  BadResourceException, ResourceNotFoundException
		 - Author			:	Jhansi
		 - Creation Date    :   12/11/2020
		 - Description		:	Adding Stock Details by passing Stock as parameter
		                           and returning Stock as return type
		  *
		  *
		  *
		*****************************/
	
	public Stock addStockDetails(Stock stock);
	
//	*************************************************
	
	
	//--------------------------------STOCK MODULE---------------------------
	/***********************
	 * 
	 * 
	 * 
	 * Function Name	:	updateStockDetails
	 - Input Parameters	:	stock object
	 - Return Type		:   Stock stock
	 - Throws			:   BadResourceException, ResourceNotFoundException
	 - Author			:	Jhansi
	 - Creation Date    :   12/11/2020
	 - Description		:	updating stock details by passing Stock as parameter 
		                           and returning Stock as return type
	 *
	 *
	 *
	 *************************/
	
    public Stock updateStockDetails(int stockId,Stock stock);
    
//	*************************************************
    
  //---------------------STOCK MODULE--------------------
  	/***********************
  	 * 
  	 * 
  	 * 
  	 * Function Name	:	viewStockDetails
  	 - Input Parameters	:	int stockId
  	 - Return Type		:   Stock stock
  	 - Throws			:   ResourceNotFoundException
  	 - Author			:	Jhansi
  	 - Creation Date    :   12/11/2020
  	 - Description		:	viewing stock details by passing stockId as parameter
  		                           and returning Stock as return type
  	 *
  	 *
  	 *
  	 *************************/
    
    
	public Stock viewStockDetails(int stockId);
	
//	*************************************************
	
	//------------------------STOCK MODULE------------------------------
	/***********************
	 * 
	 * 
	 * Function Name	:	removeStockDetails
	 - Input Parameters	:	int stockId
	 - Return Type		:   Stock stock
	 - Throws			:   ResourceNotFoundException
	 - Author			:	Jhansi
	 - Creation Date    :   12/11/2020
	 - Description		:	removing stock details by passing stockId as parameter
  		                           and returning Stock as return type
	 *
	 *
	 *
	 **************************/
	
    public Stock removeStockDetails(int stockId);
    
//	*************************************************
    
  //--------------------------------STOCK MODULE----------------------------
	/***********************
	 * 
	 * 
	 * Function Name	:	viewAllStockDetails
	 - Input Parameters	:	
	 - Return Type		:   Stock list
	 - Throws			:  	
	 - Author			:	Jhansi
	 - Creation Date    :   12/11/2020
	 - Description		:	viewing all stock details and  returning stock
	                        list as return type
	 *
	 *
	 *
	 **************************/
    
	public List<Stock> viewAllStockDetails();
	
//	*************************************************
	
	
	
	//----------------------------------STOCK MODULE-----------------------------
	/***********************
	 * 
	 * 
	 * Function Name	:	viewAllStockByCompanyDetails
	 - Input Parameters	:	String Companyname
	 - Return Type		:   Stock list
	 - Throws			:   ResourceNotFoundException
	 - Author			:	Jhansi
	 - Creation Date    :   12/11/2020
	 - Description		:	viewing all stock details  by using company name
	 -                       by passing name as argument and returning stock as 
	                         return type
	 *
	 *
	 *
	 **************************/
	
	
	public Stock viewStockByCompanyName(String name) ;
	
//	*************************************************
	
	//-------------STOCK MODULE--------------------
	/***********************
	 * 
	 * 
	 * Function Name	:	viewAllStockByInvestorName
	 - Input Parameters	:	String Investorname
	 - Return Type		:   Stock list	
	 - Author			:	Jhansi
	 - Creation Date    :   12/11/2020
	 - Description		:	viewing all stock details  by using Investor name
	                         by passing name as argument and returning stock 
	                         as  return type
	 *
	 *
	 *
	 **************************/
	
	
	
	public List<Stock> viewStockByInvestorName(String name);
	
//	*************************************************
	
	
	//-------------STOCK MODULE--------------------
	/***********************
	 * 
	 * 
	 * Function Name	:   viewAllGrowingStocks	
	 - Input Parameters	:   double avgPrice
	 - Return Type		:   Stock list
	 - Throws			:  	ResourceNotFoundException
	 - Author			:	Jhansi
	 - Creation Date    :   12/11/2020
	 - Description		:	viewing all growing stocks by passing avgPrice as argument 
	                        and returning stock list as return type 
	 *
	 *
	 *
	 **************************/
	
	
	public List<Stock> viewAllGrowingStocks(double avgPrice); 
	
//	*************************************************
	
	//-----------------------------STOCK MODULE----------------------------------
	/***********************
	 * 
	 * 
	 * Function Name	:	viewAllStockByReducingStocks
	 - Input Parameters	:	double avgPrice
	 - Return Type		:   Stock list
	 - Throws			:  	ResourceNotFoundException
	 - Author			:	Jhansi
	 - Creation Date    :   26/10/2020
	 - Description		:	viewing all reducing stocks by passing avgPrice as argument 
	                        and returning stock list as return type  
	 *
	 *
	 *
	 **************************/
	
	
	public List<Stock> viewAllReducingStocks(double avgPrice);

//	*************************************************
}