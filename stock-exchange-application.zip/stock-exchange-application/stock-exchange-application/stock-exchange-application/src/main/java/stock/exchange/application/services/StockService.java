package stock.exchange.application.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



import org.springframework.util.StringUtils;

import stock.exchange.application.exceptions.BadResourceException;
import stock.exchange.application.exceptions.ResourceNotFoundException;
import stock.exchange.application.models.Stock;
import stock.exchange.application.repositories.StockRepository;

/**
 * 
 * @author jhansi
 *
 */

@Service   //@Service annotation is used to mark the class as a service provider
public class StockService 
{  //StockService should implement all the methods present in IstockService interface
	
	@Autowired//To get a relation with Stock repository

	StockRepository stockRepository;
	
	/*
	 *------------------------------------------------------------------------------------------
	 * *********EXISTSBYID METHOD**************
	 * -----------------------------------------------------------------------------------------
	 * 
	 **/
	
	 private boolean existsById(int stockId) {
	        return stockRepository.existsById(stockId);
    }
	 
	/*
	 *------------------------------------------------------------------------------------------
	 * *********ADDSTOCKDETAILS METHOD**************
	 * -----------------------------------------------------------------------------------------
	 * 
	 **/

	public Stock addStockDetails(Stock stock) throws BadResourceException, ResourceNotFoundException{
	 if (!StringUtils.isEmpty(stock.getStockName())) {
		   if ( existsById(stock.getStockId())) {
		          throw new ResourceNotFoundException("Stock with id: " + stock.getStockId()+ "already exists");//throws exception if already stockId exists

	 }
		    return  stockRepository.save(stock);//save is used to insert the records in the table

	}
	else {
		     BadResourceException exc = new BadResourceException("Failed to save Stock details");
		     exc.addErrorMessage("Stock is null or empty");
		     throw exc;
	   }
	}
	
	
	/*
	 *---------------------------------------------------------------------------------------------
	 * *********UPDATESTOCKDETAILS METHOD**************
	 * ----------------------------------------------------------------------------------------------
	 * 
	 **/
	
	public Stock updateStockDetails(int stockId,Stock stock) throws BadResourceException, ResourceNotFoundException {
    if (!StringUtils.isEmpty(stock.getStockName())) {
	    if (!existsById(stockId)) {
	           throw new ResourceNotFoundException("Cannot find stock with id: " + stockId);//throws exception if stockId can't find
	    }
	        return  stockRepository.save(stock);//save is used to update the records in the table

	}
     else {
	     BadResourceException exc = new BadResourceException("Failed to save Stock details");
	     exc.addErrorMessage("Stock is null or empty");
	     throw exc;
	        }
	 }

	/*
	 *--------------------------------------------------------------------------------------------
	 * *********VIEWSTOCKDETAILS METHOD**************
	 * -------------------------------------------------------------------------------------------
	 * 
	 **/
	
	public Stock viewStockDetails(int stockId) throws ResourceNotFoundException {
		Stock stock1=stockRepository.findById(stockId).orElse(null);//findById method is a default method available in JPARepository
		if(stock1==null) {
			throw new ResourceNotFoundException("Cannot find stock with id: " +stockId);//throws exception if stockId can't find
		}
		else return stock1;
	}

	/*
	 *-----------------------------------------------------------------------------------------------
	 * *********REMOVESTOCKDETAILS METHOD**************
	 * ---------------------------------------------------------------------------------------------
	 * 
	 **/
	
	   public int removeStockDetails(int stockId) throws ResourceNotFoundException {
		   
	 Optional<Stock> stock=stockRepository.findById(stockId);
	 if (!existsById(stockId)) { 
         throw new ResourceNotFoundException("Cannot find stock with id: " + stockId);//throws exception if stockId can't find
     }
	 else {
	    	return stockRepository.deleteById(stockId); //deleteById Query written in StockRepository class
			
	    		   
	 }
	                
	   }
	   
	   /*
		 *
		 *----------------------------------------------------------------------------------------------
		 * *********VIEWALLSTOCKDETAILS METHOD**************
		 * ---------------------------------------------------------------------------------------------
		 * 
		 **/

	public List<Stock> viewAllStockDetails() {

	
		List<Stock> stock=new ArrayList<Stock>();
		stockRepository.findAll().forEach(stock1->stock.add(stock1));//findAll() method is used to get all the records present in the table
		return stock;
		
	}

	/*
	 *---------------------------------------------------------------------------------------------------
	 * *********VIEWSTOCKBYCOMPANYNAME METHOD**************
	 * -------------------------------------------------------------------------------------------------
	 * 
	 **/

	public Stock viewStockByCompanyName(String name) throws ResourceNotFoundException {

	 Stock stock1=	stockRepository.findByCompanyName(name);//findByCompanyName Query written in StockRepository class
		if(stock1==null) {
			throw new ResourceNotFoundException("Cannot find stock with company name: "+name );//throws exception if company name can't find in stock
		}
		else return stock1;
		
	}

	/*
	 *--------------------------------------------------------------------------------------------------
	 * *********VIEWSTOCKBYINVESTORNAME METHOD**************
	 * ---------------------------------------------------------------------------------------------------
	 * 
	 **/

	public List<Stock> viewStockByInvestorName(String name) {
		List<Stock> stock=new ArrayList<Stock>();//findByCompanyName Query written in StockRepository class
		stockRepository.findByInvestor(name).forEach(stock1->stock.add(stock1));
		return stock;
	}


	/*
	 *------------------------------------------------------------------------------------------------
	 * *********VIEWALLREDUCINGSTOCKS METHOD**************
	 * ------------------------------------------------------------------------------------------------
	 * 
	 **/

	public List<Stock> viewAllReducingStocks(double avgPrice) throws ResourceNotFoundException {

		List<Stock> stock=new ArrayList<Stock>();
		if(avgPrice <= 200) {
		stockRepository.findAll().forEach(stock1->stock.add(stock1));
		return stock;
		}
		else {
			throw new ResourceNotFoundException("avgPrice should be less than or equal to 200"); //throws exception if avgPrice is <= 200
		}
	}
	
	
	/*
	 *
	 *----------------------------------------------------------------------------------------------
	 * *********VIEWALLGROWINGSTOCKS METHOD**************
	 * ----------------------------------------------------------------------------------------------
	 * 
	 **/

	public List<Stock> viewAllGrowingStocks(double avgPrice)  throws ResourceNotFoundException{

		List<Stock> stock=new ArrayList<Stock>();
		if(avgPrice > 200) {
		stockRepository.findAll().forEach(stock1->stock.add(stock1));
		return stock;
		}
		else {
			throw new ResourceNotFoundException("avgPrice should be greater than 200"); //throws exception if avgPrice is > 200
		}
	}
	 
}