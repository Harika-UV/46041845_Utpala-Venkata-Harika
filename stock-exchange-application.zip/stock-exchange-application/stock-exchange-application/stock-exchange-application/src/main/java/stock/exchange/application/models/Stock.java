package stock.exchange.application.models;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * 
 * @author jhansi
 *
 */
@Entity//This annotation indicates this class is a entity class

@Table(name = "Stock_info")//This annotation is used to create and declare the table name

/**
 * 
 * creating Stock class with the following attributes stockId,companyId,InvestorId,StockName,
 * Quantity,type,avgPrice,totalNoOfPStocks,profitLoss,status
 *
 */
public class Stock  {
	@Id
	@GeneratedValue//Id is automatically generated with this annotation

	@Column(name = "stock_id")
    private int stockId;
	
	@OneToOne(mappedBy="stock")
	//@JoinColumn(name="investor_id")
	private Investor investor;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="company_id")
	private Company company;
	
	@NotBlank(message="Stock name should not be null")
	private String stockName;
	
	@NotNull
	private int quantity;
	
	@NotBlank(message="Type should not be null")
	private String type;
	
	@NotNull
	private double avgPrice;
	
	@NotNull
	private int totalNoOfStocks;
	
	@NotNull
	private double profitLoss;
	
	@NotBlank(message="Status should not be null")
	private String status;
	
	/**
	 * 
	 * @Constructors
	 * 
	 * 
	 */
	
	
	public Stock() {//zero-parameterized constructor 
		super();
	}
	public Stock(int stockId, Investor investor, Company company, String stockName, int quantity, String type,
			double avgPrice, int totalNoOfStocks, double profitLoss, String status) {
		super();
		this.stockId = stockId;
		this.investor = investor;
		this.company = company;
		this.stockName = stockName;
		this.quantity = quantity;
		this.type = type;
		this.avgPrice = avgPrice;
		this.totalNoOfStocks = totalNoOfStocks;
		this.profitLoss = profitLoss;
		this.status = status;
	}
	public Stock(int stockId, String stockName, int quantity, String type,
			double avgPrice, int totalNoOfStocks, double profitLoss, String status) {
		super();
		this.stockId = stockId;
		this.stockName = stockName;
		this.quantity = quantity;
		this.type = type;
		this.avgPrice = avgPrice;
		this.totalNoOfStocks = totalNoOfStocks;
		this.profitLoss = profitLoss;
		this.status = status;
	}

	public Stock(Investor investor, Company company, String stockName, int quantity, String type, double avgPrice,
			int totalNoOfStocks, double profitLoss, String status) {
		super();
		this.investor = investor;
		this.company = company;
		this.stockName = stockName;
		this.quantity = quantity;
		this.type = type;
		this.avgPrice = avgPrice;
		this.totalNoOfStocks = totalNoOfStocks;
		this.profitLoss = profitLoss;
		this.status = status;
	}
	public Stock(String stockName, int quantity, String type, double avgPrice, int totalNoOfStocks, double profitLoss,
			String status) {
		super();
		this.stockName = stockName;
		this.quantity = quantity;
		this.type = type;
		this.avgPrice = avgPrice;
		this.totalNoOfStocks = totalNoOfStocks;
		this.profitLoss = profitLoss;
		this.status = status;
	}
	
	
	/**
	 * 
	 * @getters and setters
	 * 
	 */
	public int getStockId() {
		return stockId;
	}
	public void setStockId(int stockId) {
		this.stockId = stockId;
	}
	public Investor getInvestor() {
		return investor;
	}
	public void setInvestor(Investor investor) {
		this.investor = investor;
	}
	public Company getCompany() {
		return company;
	}
	public void setCompany(Company company) {
		this.company = company;
	}
	public String getStockName() {
		return stockName;
	}
	public void setStockName(String stockName) {
		this.stockName = stockName;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public double getAvgPrice() {
		return avgPrice;
	}
	public void setAvgPrice(double avgPrice) {
		this.avgPrice = avgPrice;
	}
	public int getTotalNoOfStocks() {
		return totalNoOfStocks;
	}
	public void setTotalNoOfStocks(int totalNoOfStocks) {
		this.totalNoOfStocks = totalNoOfStocks;
	}
	public double getProfitLoss() {
		return profitLoss;
	}
	public void setProfitLoss(double profitLoss) {
		this.profitLoss = profitLoss;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "Stock [stockId=" + stockId + ", stockName=" + stockName + ", quantity=" + quantity + ", type=" + type
				+ ", avgPrice=" + avgPrice + ", totalNoOfStocks=" + totalNoOfStocks + ", profitLoss=" + profitLoss
				+ ", status=" + status + "]";
	}
	
	
	
}