package stock.exchange.application.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import stock.exchange.application.models.Company;



@Repository
public interface CompanyRepository extends JpaRepository<Company,Integer>
{

	/*@Query("delete from Company c where c.companyId=:companyId")
	Company deleteById(@Param("companyId")int companyId);*/
}