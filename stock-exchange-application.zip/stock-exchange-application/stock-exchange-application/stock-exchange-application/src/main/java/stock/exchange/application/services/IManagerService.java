package stock.exchange.application.services;
import java.util.List;

import stock.exchange.application.models.Manager;


public interface IManagerService 
{
	//------------------------ 1. StockExchanageManagement Application --------------------------
		/*******************************************************************************************************
		 - Function Name	:	addManagerInfo(Manager info) 
		 - Input Parameters	:	Manager info
		 - Return Type		:	Manager
		 - Author			:	JennyThanushaw
		 - Creation Date	:	10/11/2020
		 - Description		:	Adding Manager details to database calls Controller method addManagerInfo(Manager info)

		 ********************************************************************************************************/
	
	public Manager addManagerInfo(Manager info);
	

	//------------------------ 1. StockExchangeManagement Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	getAllManagerInfo() 
	 - Input Parameters	:	No
	 - Return Type		:	List<Manager>
	 - Author			:	JennyThanushaw
	 - Creation Date	:	10/11/2020
	 - Description		:   Getting Manager details in database calls Controller method getAllManagerInfo()

	 ********************************************************************************************************/
	
	public List<Manager> getAllManagerInfo();
	
	//------------------------ 1. StockExchangeManagement Application --------------------------
		/*******************************************************************************************************
		 - Function Name	:	getManagerDetails(Integer managerId);
		 - Input Parameters	:	Integer managerId
		 - Return Type		:	manager
		 - Author			:	JennyThanushaw
		 - Creation Date	:	10/11/2020
		 - Description		:	Getting Manager details from database calls Controller method getManagerDetails(Integer ManagerId)

		 ********************************************************************************************************/
	public Manager getManagerDetails(int managerId);
	
	//------------------------ 1. StockExchangeManagement Application --------------------------
			/*******************************************************************************************************
			 - Function Name	:	updateManagerInfo(Manager info) 
			 - Input Parameters	:	Manager info
			 - Return Type		:	manager
			 - Author			:	JennyThanushaw
			 - Creation Date	:	10/11/2020
			 - Description		:	updating Manager details to database calls Controller method UpdateManagerInfo(Manager info)

			 ********************************************************************************************************/
		
	public Manager updateManagerInfo(Manager info) ;
	
	//------------------------ 1. StockExchangeManagement Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	getManager(Company company) 
	 - Input Parameters	:	Company company
	 - Return Type		:	manager
	 - Author			:	JennyThanushaw
	 - Creation Date	:	10/11/2020
	 - Description		:	updating Manager details to database calls Controller method UpdateManagerInfo(Manager info)

	 ********************************************************************************************************/
	
	
	
	//------------------------ 1. StockExchangeManagement Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	deleteManagerInfo(Manager info) 
	 - Input Parameters	:	Manager info
	 - Return Type		:	manager
	 - Author			:	JennyThanushaw
	 - Creation Date	:	10/11/2020
	 - Description		:	deleting Manager details to database calls Controller method deleteManagerInfo(Integer managerId)

	 ********************************************************************************************************/

	public Manager deleteManagerInfo(int managerId);
}
