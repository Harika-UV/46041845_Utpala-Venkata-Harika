package stock.exchange.application.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.Pattern;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

@Entity//This annotation indicates this class is a entity class

@Table(name="manager_info")//This annotation is used to create and declare the table name

public class Manager 
{
	@Id
	@GeneratedValue//Id is automatically generated with this annotation

	@Column(name = "manager_id")
	private int managerId;
	
	@NotBlank(message="Manager name should not be null")
	private String managerName;
	
    @Pattern(regexp ="[A-Za-z]{1}[A-Za-z0-9#$%^&*]+[@][A-Za-z]+[.][A-Za-z]+",message="Please provide valid manager email")
	private String email;
    
    @Pattern(regexp ="[6-9]{1}[0-9]{9}",message="Please enter valid manager mobileno")
	private String mobileNo;	
    /**
	 * 
	 * @Constructors
	 * 
	 * 
	 */
	
	public Manager() {//zero-parameterized constructor 
		
	}

	public Manager(int managerId, String managerName, String email, String mobileNo) {
		super();
		this.managerId = managerId;
		this.managerName = managerName;
		this.email = email;
		this.mobileNo = mobileNo;
	}

	public Manager(String managerName, String email, String mobileNo) {
		super();
		this.managerName = managerName;
		this.email = email;
		this.mobileNo = mobileNo;
	}
	
	/**
	 * 
	 * @getters and setters
	 * 
	 * 
	 */
	
	public int getManagerId() {
		return managerId;
	}

	public void setManagerId(int managerId) {
		this.managerId = managerId;
	}

	public String getManagerName() {
		return managerName;
	}

	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	/**
	 * 
	 * @toString method
	 * 
	 */
	

	@Override
	public String toString() {
		return "Manager [managerId=" + managerId + ", managerName=" + managerName + ", email=" + email + ", mobileNo="
				+ mobileNo + "]";
	}
}