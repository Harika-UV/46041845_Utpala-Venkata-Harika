package stock.exchange.application.models;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
/**
 * 
 * @author jhansi
 *
 */
@Entity//This annotation indicates this class is a entity class

@Table(name = "bank_account")//This annotation is used to create and declare the table name

public class BankAccount {
	
	@NotBlank(message="Bankname should not be null")
	private String bankName;
	
	@NotBlank(message="Branchname should not be null")
	private String branchName;
	
	@Id
	@GeneratedValue//Id is automatically generated with this annotation

	private long accountNo;
	
	@NotNull
	@Digits(message="invalid amount",integer=6, fraction=2)
	private double balance;
	
	/**
	 * 
	 * @Constructors
	 * 
	 * 
	 */
	public BankAccount() {//zero-parameterized constructor 
		super();
	}
	
	
	public BankAccount(String bankName, String branchName, double balance) {
		super();
		this.bankName = bankName;
		this.branchName = branchName;
		this.balance = balance;
	}

	public BankAccount(String bankName, String branchName, long accountNo, double balance) {
		super();
		this.bankName = bankName;
		this.branchName = branchName;
		this.accountNo = accountNo;
		this.balance = balance;
	}
	
	/**
	 * 
	 * @getters and setters
	 * 
	 */
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	/**
	 * 
	 * toString method
	 * 
	 * 
	 */
	@Override
	public String toString() {
		return "BankAccount [bankName=" + bankName + ", branchName=" + branchName + ", accountNo=" + accountNo
				+ ", balance=" + balance + "]";
	}
	
}
