package stock.exchange.application.models;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * 
 * @author jhansi
 *
 */
@Entity//This annotation indicates this class is a entity class

@Table(name = "company_info")//This annotation is used to create and declare the table name

public class Company {
	@Id
	@GeneratedValue//Id is automatically generated with this annotation

	@Column(name = "company_id")
	private int companyId;
	
	@NotBlank(message="company name should not be null")
	private String companyName;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="manager_id")
	private Manager manager;
	
	@NotNull
	private int noOfStocks;
	
	@NotNull
	//@Digits(message="invalid stockprice",integer=3, fraction=2)
	private double stockPrice;
	
	@NotNull
	//@Digits(message="invalid percentage change",integer=2, fraction=2)
	private double percentageChange;
	
	/**
	 * 
	 * @Constructors
	 * 
	 * 
	 */
	
	public Company() {//zero-parameterized constructor 
		super();
	}
	
	
	public Company(int companyId,String companyName,int noOfStocks,double stockPrice,double percentageChange) {
		super();
		this.companyId = companyId;
		this.companyName = companyName;
		this.noOfStocks = noOfStocks;
		this.stockPrice = stockPrice;
		this.percentageChange = percentageChange;
	}


	public Company(String companyName, Manager manager, int noOfStocks, double stockPrice, double percentageChange) {
		super();
		this.companyName = companyName;
		this.manager = manager;
		this.noOfStocks = noOfStocks;
		this.stockPrice = stockPrice;
		this.percentageChange = percentageChange;
	}
	public Company(int companyId, String companyName, Manager manager, int noOfStocks, double stockPrice,
			double percentageChange) {
		super();
		this.companyId = companyId;
		this.companyName = companyName;
		this.manager = manager;
		this.noOfStocks = noOfStocks;
		this.stockPrice = stockPrice;
		this.percentageChange = percentageChange;
	}
	
	/**
	 * 
	 * @getters and setters
	 * 
	 */
	
	public Company(String companyName) {
		super();
		this.companyName = companyName;
	}
	public int getCompanyId() {
		return companyId;
	}
	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public Manager getManager() {
		return manager;
	}
	public void setManager(Manager manager) {
		this.manager = manager;
	}
	public int getNoOfStocks() {
		return noOfStocks;
	}
	public void setNoOfStocks(int noOfStocks) {
		this.noOfStocks = noOfStocks;
	}
	public double getStockPrice() {
		return stockPrice;
	}
	public void setStockPrice(double stockPrice) {
		this.stockPrice = stockPrice;
	}
	public double getPercentageChange() {
		return percentageChange;
	}
	public void setPercentageChange(double percentageChange) {
		this.percentageChange = percentageChange;
	}
	/**
	 * 
	 * @toString method
	 * 
	 * 
	 */
	@Override
	public String toString() {
		return "Company [companyId=" + companyId + ", companyName=" + companyName + ", manager=" + manager
				+ ", noOfStocks=" + noOfStocks + ", stockPrice=" + stockPrice + ", percentageChange=" + percentageChange
				+ "]";
	}
	
}
