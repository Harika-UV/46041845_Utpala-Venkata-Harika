package stock.exchange.application.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import stock.exchange.application.models.Manager;

@Repository
public interface ManagerRepository extends JpaRepository<Manager, Integer> {

	/*@Query("delete from Manager m where m.managerId=:managerId")
	Manager deleteById(@Param("managerId")int managerId);*/
}
