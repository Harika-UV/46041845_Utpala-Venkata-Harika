package stock.exchange.application.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import stock.exchange.application.models.User;

@Repository
public interface UserRepository extends JpaRepository<User,Integer>{   //All the methods present in JPARepository can be used by UserRepository
	List<User> findAll();
	void deleteById(int userId);
		
}

