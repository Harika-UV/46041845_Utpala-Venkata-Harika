package stock.exchange.application.exceptions;

/*
 * 
 * @author Jahnavi
 * 
 * */
public class InvalidOperation extends RuntimeException {
	public InvalidOperation(String msg)
	{
		super(msg);
	}

}
