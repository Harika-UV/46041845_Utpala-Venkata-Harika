package stock.exchange.application.repositories;




import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import stock.exchange.application.models.Stock;

/**
 * 
 * @author jhansi
 *
 */

@Repository//@Repository annotation is used to mark the class as a Repository provider
public interface StockRepository extends JpaRepository<Stock, Integer>
//All the methods present in JPARepository can be used by StockRepository
{
	
	
		@Modifying  // returns 1
		//Query statement for removeStockDetailsmethod
		@Query("delete from Stock s where s.stockId=:stockId")
		int deleteById(@Param("stockId")int stockId);

		//Query statement for viewStockByInvestorName method
		@Query("SELECT s FROM Stock s WHERE s.investor.investorName LIKE ?1%  ")
	  	Iterable<Stock> findByInvestor(@Param("name")String  name);
	  
		//Query statement for viewStockByCompanyName method
		@Query("SELECT s FROM Stock s WHERE s.company.companyName LIKE ?1%")
		Stock findByCompanyName(@Param("name") String name);
	  
	


}