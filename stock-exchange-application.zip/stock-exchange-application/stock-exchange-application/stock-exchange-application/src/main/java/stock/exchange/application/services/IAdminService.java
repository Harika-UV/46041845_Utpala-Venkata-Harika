package stock.exchange.application.services;
import java.util.List;

import stock.exchange.application.models.Admin;

public interface IAdminService {
	public Admin getAdminById(Integer id);
	public Admin insertAdmin(Admin admin);
	public Admin updateAdmin(Admin admin,Integer id);
	public boolean deleteAdmin(Integer id);
	public List<Admin> getAllAdmins();

}
