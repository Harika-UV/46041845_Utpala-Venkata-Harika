package stock.exchange.application.services;

import java.util.List;

import stock.exchange.application.models.Investor;



public interface InterfaceInvestorService {

	public Investor addInvestor(Investor info);
	public  List<Investor> getAllInvestor();
	public Investor getInvestorDetails(String investorId);
	public Investor  updateInvestor(Investor info);
	public Investor deleteInvestor(Investor inv);
	public List<Investor> viewAllInvestorCompany(String companyName);
	public List<Investor> viewAllInvestorStock(String companyName);
}
