package stock.exchange.application.services;

import stock.exchange.application.models.User;

public interface IUserService {   //By default all the methods present in interface are public abstract
	public String login(User user);
	
	//******************StockApp**********************//
			/* Function Name: login(User user)
			 * Input Parameters: (User user)
			 * ReturnType: User
			 * creation Date: 13/11/2020
			 * Author: Jahnavi
			 * Description: login the page by user using UserName and the password*/
	
	public User insertUser(User user);
	
	//******************StockApp**********************//
	/* Function Name: insertUser(User user)
	 * Input Parameters: (User user)
	 * ReturnType: User
	 * creation Date: 13/11/2020
	 * Author: Jahnavi
	 * Description: insert the user by giving the needed credentials  */
	
	public boolean deleteUserbyName(String userName);
	
	//******************StockApp**********************//
		/* Function Name: deleteUserbyName(String userName)
		 * Input Parameters: (String userName)
		 * ReturnType: String
		 * creation Date: 13/11/2020
		 * Author: Jahnavi
		 * Description: delete the user by giving the needed credentials */
	
	public String logout(User user);
	
	//******************StockApp**********************//
			/* Function Name: logout(User user)
			 * Input Parameters: (User user)
			 * ReturnType: User
			 * creation Date: 13/11/2020
			 * Author: Jahnavi
			 * Description: logout the page */
}
