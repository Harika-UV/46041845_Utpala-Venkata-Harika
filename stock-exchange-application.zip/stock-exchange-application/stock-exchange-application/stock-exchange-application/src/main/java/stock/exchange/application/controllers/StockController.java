package stock.exchange.application.controllers;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import stock.exchange.application.exceptions.BadResourceException;
import stock.exchange.application.exceptions.ResourceNotFoundException;
import stock.exchange.application.models.Admin;
import stock.exchange.application.models.Stock;
import stock.exchange.application.services.StockService;
import io.swagger.annotations.ApiParam;

/**
 * 
 * @author jhansi
 *
 */
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/stk/")  
@RestController
public class StockController
{
	Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired//To establish the relationship with stock service class

	StockService stockService ;
	
	
	@PostMapping("/Stock")//@PostMapping is used to insert stock records

	public ResponseEntity<Stock> addStockDetails(@Valid @RequestBody Stock stock) {

		try {
			
			return new ResponseEntity<>(stockService.addStockDetails(stock),HttpStatus.OK);
		}
		catch (ResourceNotFoundException e) {
            // log exception first, then return Conflict (409)
            logger.info("Stock already exists"+e);
            return ResponseEntity.status(HttpStatus.CONFLICT).build();
        } catch (BadResourceException e) {
            // log exception first, then return Bad Request (400)
            logger.info(e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }	
	}
	

	@PutMapping("/Stock/{stockId}")//@PutMapping is used to update stock records based on stockId

	public ResponseEntity<Stock> updateStockDetails(@PathVariable("stockId") int stockId,@Validated @RequestBody Stock stock) throws BadResourceException, ResourceNotFoundException  {
		
			Stock updatedStock= stockService.updateStockDetails(stockId,stock);
			return ResponseEntity.ok(updatedStock);
		}
	

	@GetMapping("/Stockv/{stockId}")//To get the stock record based on stock id

	public Stock viewStockDetails(@PathVariable("stockId") int stockId) throws ResourceNotFoundException  {
		return stockService.viewStockDetails(stockId);
	}
	
	@DeleteMapping("/Stock/{stockId}")//@DeleteMapping is used to delete stock records based on stock id

	public int removeStockDetails( @PathVariable("stockId") int stockId) throws ResourceNotFoundException  {
		
		 return stockService.removeStockDetails(stockId);
    }
 
	
	@GetMapping("/Stock")//@GetMapping is used to get all the stock records in the table

	public List<Stock> viewAllStockDetails() {
			
			return stockService.viewAllStockDetails();
	}



	  @GetMapping("/Stock/{name}")//To get the stock record based on company name
		public Stock viewStockByCompanyName(@PathVariable("name") String name) throws ResourceNotFoundException {
	    	
			return stockService.viewStockByCompanyName(name);
		}

	   @GetMapping("/Stock/StockByName/{name}")//To get the stock records based on investor name
	   public List<Stock> viewStockByInvestorName(@PathVariable("name") String name) {

			return stockService.viewStockByInvestorName(name);
		}
 

		@GetMapping("/Stock/growingstocks")//To get all the growing stock record based on avgPrice
		public List<Stock> viewAllGrowingStocks(double avgPrice) throws ResourceNotFoundException {

			return stockService.viewAllGrowingStocks(avgPrice);
		}

		@GetMapping("/Stock/reducingstocks")//To get all the reducing stock record based on avgPrice
		public List<Stock> viewAllReducingStocks(double avgPrice) throws ResourceNotFoundException {
			
			return stockService.viewAllReducingStocks(avgPrice);
		}

}