package stock.exchange.application.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import stock.exchange.application.exceptions.InvalidOperation;
import stock.exchange.application.models.User;
import stock.exchange.application.repositories.UserRepository;

@Service   
public class UserService{   
	@Autowired  
	private UserRepository urRepository;
	
	public int registerUser(User user)
	{
		if(urRepository.existsById(user.getId()))
		{
		     return 0;
		}
		else
		{
		   return urRepository.save(user).getId();
		}
			 
	}
	
    public User updateUser(int id, User user) throws InvalidOperation
    {

	      Optional<User> repUser = urRepository.findById(id);

	        if (repUser.isPresent()) {

		    //User userToBeUpdated = repUser.get();
		    /*userToBeUpdated.setPassword(user.getPassword());
		    userToBeUpdated.setFirstName(user.getFirstName());
		    userToBeUpdated.setLastName(user.getLastName());
		    userToBeUpdated.setEmail(user.getEmail());
		    userToBeUpdated.setContactno(user.getContactno());*/
		   
		    return urRepository.save(user);
	      }
	      else
	      {
				throw new InvalidOperation("No User present with the given Id to Update...Please enter valid Id to update");

	      }
      }
   
     public int deleteUser(int id) throws InvalidOperation
     {
    	 Optional<User> repUser = urRepository.findById(id);
    		 
    	  if(repUser.isPresent())
    	   {
    	      urRepository.deleteById(id);
              System.out.println("User details are deleted Successfully");
    		}
    	    else
    		{
    		    throw new InvalidOperation("Enter valid Id to be deleted");
    		}
		    return id;
      }
     
   
	 public User findByUserId(int id) throws InvalidOperation
	 {
	      Optional<User> repUser = urRepository.findById(id);
	      
	      if(repUser.isPresent())
	      {
			 return repUser.get();
		  }
	      else
	      {
  		    throw new InvalidOperation("Enter valid Id to view the User details"); 
	      }
		
	 }
	 
	 
	 public List<User> getAllUsers()
	 {
	 
		System.out.println("Users...");
		return urRepository.findAll();
	 }
}

	/*public String login(User user) {
		String userName=user.getUserName();
		User loginUser=userrepository.findById(userName).get(); //findById is used to find the particular record using id
		if(loginUser==null)
		{
			try {
			throw new InvalidOperation("Incorrect details... Enter valid Information");
			}
			catch(InvalidOperation ie)  //throws exception if the details entered by user does not match the database records
			{
				System.out.println(ie);
			}
		}
		else
		{
			String pwd=loginUser.getUserPassword();
			String user_name=loginUser.getUserName();
			if(pwd.equals(user.getUserPassword()) && user_name.equalsIgnoreCase(user.getUserName()))
			{
				String str=loginUser.getUserName()+" logged in successfully ";
				return str;
			}
		}
		return null;
	}
	
	/*public User insertUser(User user) {
		if(user!=null)
		{
			return userrepository.save(user);  //save is used to insert the records in the table
		}
		else
		{
			throw new InvalidOperation("User not added..Please enter correct information...");
		}
	}
	public boolean deleteUserbyName(String userName) {
		if(userName!=null) {
			userrepository.deleteById(userName); //deleteAdminbyId() is a predefined method present in JPARepository
			return true;
		}
		else
		{
			throw new InvalidOperation("User not deleted..Please enter correct information...");
		}
	
	}
	
	public String logout(User user) {
		return  user.getUserName()+ " logged out successfully";
	}*/