package stock.exchange.application.controllers;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import stock.exchange.application.exceptions.BadResourceException;
import stock.exchange.application.exceptions.ResourceNotFoundException;
import stock.exchange.application.models.Manager;
import stock.exchange.application.services.ManagerService;



//connect from postman as http://localhost:8086/swagger-ui.html
@CrossOrigin(origins="http://localhost:3000")
@Controller
@RequestMapping("/mana/")
public class ManagerController {
	//Logger logger=LoggerFactory.getLogger(ManagerController.class);
	@Autowired
	ManagerService managerService;

	//Creating a post mapping that post the Manager detail into the database
	
	@PostMapping("/managers")
	public @ResponseBody Manager addManagerInfo(@RequestBody Manager info) throws BadResourceException, ResourceNotFoundException 
	{
		//logger.info("manager service was instalized");
		return managerService.addManagerInfo(info);
	}
	
	//Creating a get mapping that retrives the all Manager info from the database
	
	@GetMapping("/managers")
	public @ResponseBody List<Manager> getAllManagerInfo() 
	{ 
		
		 return managerService.getAllManagerInfo();
	}
	
	//Creating a get mapping that retrives the details of a specific Manager info
	
	@GetMapping("/managers/{managerId}")
	public @ResponseBody Manager getManagerDetails(@PathVariable int managerId) throws ResourceNotFoundException
	{
		return  managerService.getManagerDetails(managerId);
	}
	
	//Creating put mapping that updates the Manager info
	
	@PutMapping("/managers/{managerId}")
	public @ResponseBody Manager updateManagerInfo(@PathVariable int managerId,@RequestBody Manager info) throws BadResourceException, ResourceNotFoundException
	{
		return managerService.updateManagerInfo(managerId,info);
	}
	
	//Create delete mapping that deletes a specific Manager
	
	@DeleteMapping("/managers/{managerId}")
	public @ResponseBody Manager deleteManagerInfo(@PathVariable int managerId) throws ResourceNotFoundException 
	{
		return managerService.deleteManagerInfo(managerId);
	}
	

	
	
}

	
	
	