package stock.exchange.application.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import stock.exchange.application.exceptions.InvalidOperation;
import stock.exchange.application.models.Admin;
import stock.exchange.application.repositories.AdminRepository;




/********************AUTHOR :KOLLAREDDY JAHNAVI*****************/

@Service
public class AdminService implements IAdminService {
	@Autowired
	private AdminRepository adminRepository;
	
	private boolean existsById(int stockId) {
        return adminRepository.existsById(stockId);
}
	public Admin getAdminById(Integer id) {
		try {
			return adminRepository.findById(id).get();
		}
		catch(InvalidOperation ie)
		{
			throw new InvalidOperation("Invalid Information....Please Enter correct id...");
		}
	}
	public Admin insertAdmin(Admin admin) {
		
		try
		{
			return adminRepository.save(admin);
		}
		
		catch(InvalidOperation ie){
			
			throw new InvalidOperation("Admin not inserted..Please Enter valid information...");
		}
	
	}
	public Admin updateAdmin(Admin admin,Integer id)  {
		
//		    if (adminRepository.existsById(id)) {
//		        return  adminRepository.save(admin);//save is used to update the records in the table
//
//		}
//	     else {
//		     BadResourceException exc = new BadResourceException("Failed to save Stock details");
//		     exc.addErrorMessage("Stock is null or empty");
//		     throw exc;
//		        }
	Optional<Admin> repAdmin=adminRepository.findById(id);
	if(repAdmin.isPresent())
	{
		return adminRepository.save(admin);
	}
	
	else
	{
		throw new InvalidOperation("Failed to save Stock details");
	}
	}
	public boolean deleteAdmin(Integer id) {
		try {
			adminRepository.deleteById(id);
			return true;
		}
		catch(InvalidOperation ie)
		{
			throw new InvalidOperation("Admin not deleted..Please Enter valid information...");
		}
	
	}
	public List<Admin> getAllAdmins() {
		List<Admin> adminlist=new ArrayList<>();
		adminRepository.findAll().forEach(admin->adminlist.add(admin));
		return adminlist;
	}
	
	
}