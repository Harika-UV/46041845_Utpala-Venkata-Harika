package stock.exchange.application.services;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import stock.exchange.application.exceptions.BadResourceException;
import stock.exchange.application.exceptions.InvalidOperation;
import stock.exchange.application.exceptions.ResourceNotFoundException;
import stock.exchange.application.models.Company;
import stock.exchange.application.repositories.CompanyRepository;


@Service
public class CompanyService
{
	//Logger logger = LoggerFactory.getLogger(CompanyService.class);
	
	@Autowired
	CompanyRepository companyRepository;
	
	private boolean existsById(int companyId) {
        return companyRepository.existsById(companyId);
	}

	/***************************Add Company Details***********************************/
	
//	public Company addCompanyInfo(Company info) throws InvalidOperation 
//	{
//		logger.info("add company info started execution");
//		if((info!=null)&&(Validations.name(info.getCompanyName())) && (Validations.name(info.getManager().getManagerName())) && 
//		   (Validations.email(info.getManager().getEmail())) && (Validations.mobileNo(info.getManager().getMobileNo())) &&
//		   (info.getNoOfStocks()>=0) &&(info.getPercentageChange()>=0) &&(info.getStockPrice()>=0))
//		{
//			logger.info("company details are valid");
//			return compRepository.save(info);
//		}
//		else
//		{
//			logger.info("company details are not valid");
//			throw new InvalidOperation("Company details are not valid");
//		}
//	}
	
	public Company addCompanyInfo(Company info) throws BadResourceException, ResourceNotFoundException {
		 if (!StringUtils.isEmpty(info.getCompanyName())) {
			   if ( existsById(info.getCompanyId())) {
			          throw new ResourceNotFoundException("Stock with id: " + info.getCompanyId()+ "already exists");//throws exception if already stockId exists

		 }
			    return  companyRepository.save(info);//save is used to insert the records in the table

		}
		else {
			     BadResourceException exc = new BadResourceException("Failed to save Stock details");
			     exc.addErrorMessage("Stock is null or empty");
			     throw exc;
		   }
		}
	
	/***************************Get All Company Details*********************************/
	
	public List<Company> getAllCompanyInfo() 
	{
		//logger.info("get all company info started execution");
		return companyRepository.findAll();
	}
	
	
	
	/************************Get Company Details Based On Id*****************************/
	
	public Company getCompanyDetails(int companyId)
	{
		//logger.info("get company details started execution");
		Optional<Company> company=companyRepository.findById(companyId);
		//logger.info("searching for id");
		if(company.isPresent())
		{
			//logger.info("id present/found");
			return company.get();
		}
		else
		{
			//logger.info("id not found");
				throw new InvalidOperation("No Company details found with given id");
			}
	}

	/***************************Update Company Details
	 * @throws ResourceNotFoundException 
	 * @throws BadResourceException ***********************************/
	
//	public Company updateCompanyInfo(Company info) throws InvalidOperation 
//	{
//		logger.info("update company info started execution");
//		if((info!=null)&&(Validations.name(info.getCompanyName())) && (Validations.name(info.getManager().getManagerName())) && 
//			(Validations.email(info.getManager().getEmail())) && (Validations.mobileNo(info.getManager().getMobileNo())) &&
//			(info.getNoOfStocks()>=0) &&(info.getPercentageChange()>=0) &&(info.getStockPrice()>=0))
//		{
//			logger.info("company details are valid");
//			return compRepository.save(info);
//		}
//		else
//		{
//			logger.info("company details are not valid");
//			throw new InvalidOperation("Company details are not valid");
//		}
//	}

public Company updateCompanyInfo(int companyId,Company info) throws ResourceNotFoundException, BadResourceException {
    if (!StringUtils.isEmpty(info.getCompanyName())) {
	    if (!existsById(info.getCompanyId())) {
	           throw new ResourceNotFoundException("Cannot find company with id: " + info.getCompanyId());//throws exception if stockId can't find
	    }
	        return  companyRepository.save(info);//save is used to update the records in the table

	}
     else {
	     BadResourceException exc = new BadResourceException("Failed to save company details");
	     exc.addErrorMessage("Company is null or empty");
	     throw exc;
	        }
	 }

	
	/***************************Delete Company Details***********************************/
	
	public Company deleteCompanyInfo(int companyId) 
	{
		//logger.info("delete company info started execution");
		Optional<Company> company=companyRepository.findById(companyId);
		//logger.info("searching for id");
	    if(company.isPresent())
		{
			companyRepository.deleteById(companyId);
			//logger.info("id present/found");
			return company.get();
		}
		else
		{
			//logger.info("id not found");
			try 
			{
				throw new InvalidOperation("No Company found with given id");
		    }
		  catch(InvalidOperation e)
		  {
			//logger.info(e+"");
		  }
		  return company.get();
	   }
	}
   

/*public Company deleteCompanyInfo(int companyId) throws ResourceNotFoundException {
	   
	 Optional<Company> company=companyRepository.findById(companyId);
	 if (!existsById(companyId)) { 
        throw new ResourceNotFoundException("Cannot find company with id: " + companyId);//throws exception if stockId can't find
    }
	 else {
	    	return companyRepository.deleteById(companyId); //deleteById Query written in StockRepository class
			
	    		   
	 }
	                
	   }*/
}