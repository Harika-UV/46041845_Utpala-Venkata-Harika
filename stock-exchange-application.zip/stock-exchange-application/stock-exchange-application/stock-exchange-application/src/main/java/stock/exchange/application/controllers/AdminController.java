package stock.exchange.application.controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import stock.exchange.application.models.Admin;
import stock.exchange.application.services.AdminService;




		/********************AUTHOR :KOLLAREDDY JAHNAVI*****************/

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/v1/")
public class AdminController  {
	@Autowired
	private AdminService adminService;
	
	@GetMapping("/{id}")
	public @ResponseBody Admin getAdminById(@PathVariable Integer id)
	{
		return adminService.getAdminById(id);
		
	}
	
	
	@PostMapping("/")
	public @ResponseBody Admin insertAdmin(@RequestBody Admin admin)
	{
		return adminService.insertAdmin(admin);
	}
	
	
	@PutMapping("/{id}")
	public ResponseEntity<Admin> updateAdmin(@RequestBody Admin admin,@PathVariable Integer id) 
	{
		Admin updatedadmin= adminService.updateAdmin(admin,id);
		return ResponseEntity.ok(updatedadmin);
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteAdmin(@PathVariable Integer id)
	{
		adminService.deleteAdmin(id);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}
	
	@GetMapping(value={"/admins"})
	public @ResponseBody List<Admin> getAllAdmin()
	{
		List<Admin> adminlist=adminService.getAllAdmins();
		return adminlist;
	}
	
	
	
	
	
	
}
