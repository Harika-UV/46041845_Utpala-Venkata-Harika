package com.uvh.smai;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.uvh.smai.controllers.InvestorController;
import com.uvh.smai.exceptions.ResourceNotFoundException;
import com.uvh.smai.models.BankAccount;
import com.uvh.smai.models.Investor;
import com.uvh.smai.services.InvestorService;

@ExtendWith(MockitoExtension.class)
public class StockManagementAppInvestorApplicationTests {

	@Mock
	InvestorService investorService;
	
	@InjectMocks
	InvestorController investorController;
	
	@Test
	public void testaddInvestor() throws ResourceNotFoundException {
		BankAccount account = new BankAccount("Andhra", "Hyderabad", 35000.00);
		Investor info = new Investor("Sree", "sree@gmail.com", "Sree9999", "8987868584", "F", account);
		
		Mockito.when(investorService.addInvestor(info)).thenReturn(info);
        assertEquals(info, investorController.addInvestor(info));
	}
	
	@Test
	  public void testgetAllInvestorInfo() {
	       List<Investor> investor=new ArrayList<Investor>();
	       Mockito.when(investorService.getAllInvestors()).thenReturn(investor);
	       assertEquals(investor, investorController.getAllInvestors());
	 }
	
	@Test
	 public void testgetInvestorDetails() throws ResourceNotFoundException {
		BankAccount account = new BankAccount("HDFC", "Mumbai", 30000.00);
		Investor investor = new Investor("Divya", "divya@gmail.com", "Divya888", "9878695438", "F", account);

		int id=60;
		Mockito.when(investorService.getInvestorDetails(60)).thenReturn(investor);
	    assertEquals(investor, investorController.getInvestorDetails(60));
	 }
	
	@Test
	 public void testupdateInvestor() throws ResourceNotFoundException {
		BankAccount account = new BankAccount("ICICI", "Bangalore", 32000.00);
		Investor info = new Investor("Navya", "navya@gmail.com", "navya879", "6879054756", "F", account);		
			
		Mockito.when(investorService.updateInvestor(info)).thenReturn(info);
	    assertEquals(info,investorController.updateInvestor(info));
	 }
	 

	 @Test
	 public void testdeleteInvestor() throws ResourceNotFoundException {
		 BankAccount account = new BankAccount("ICICI", "Pune", 35000.00);
		 Investor investor = new Investor("Harish", "harish@gmail.com", "harissh3456", "8645790321", "M", account);		 
	 	
	 	int id=48;
		Mockito.when(investorService.deleteInvestor(48)).thenReturn(investor);
	 	assertEquals(investor, investorController.deleteInvestor(48));
	 	
	 }

}
