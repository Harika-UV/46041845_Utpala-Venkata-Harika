package com.uvh.smai.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.uvh.smai.exceptions.ResourceNotFoundException;
import com.uvh.smai.models.Investor;
import com.uvh.smai.services.InvestorService;

@RestController
@RequestMapping("/investor")
public class InvestorController {

	@Autowired
	private InvestorService investorService;
	
	@GetMapping("/")
	public @ResponseBody List<Investor> getAllInvestors() {
		return investorService.getAllInvestors();	
	}
	
	@GetMapping("/{investorId}")
	public @ResponseBody Investor getInvestorDetails(@PathVariable int investorId) throws ResourceNotFoundException {
		return investorService.getInvestorDetails(investorId);
	}
	
	@PostMapping("/")
	public @ResponseBody Investor addInvestor(@RequestBody Investor investor) throws ResourceNotFoundException {
		return investorService.addInvestor(investor);
	}
	
	@PutMapping("/")
	public @ResponseBody Investor updateInvestor(@RequestBody Investor info) throws ResourceNotFoundException {
		return investorService.updateInvestor(info);
	}
	
	@DeleteMapping("/{investorId}")
	public @ResponseBody Investor deleteInvestor(@PathVariable  int investorId) throws ResourceNotFoundException {
		return investorService.deleteInvestor(investorId);
	}
	
	@GetMapping("/{companyName}")
	public @ResponseBody List<Investor> viewAllInvestorCompany(@PathVariable("companyName") String companyName) {
		return investorService.viewAllInvestorCompany(companyName);
	}
	
	@GetMapping("/{stockName}")
	public @ResponseBody List<Investor> viewAllInvestorStock(@PathVariable("stockName") String stockName) {
		return investorService.viewAllInvestorStock(stockName);
	}
}

