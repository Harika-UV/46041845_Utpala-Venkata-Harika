package com.uvh.smai.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uvh.smai.exceptions.ResourceNotFoundException;
import com.uvh.smai.models.Company;
import com.uvh.smai.models.Investor;
import com.uvh.smai.models.Stock;
import com.uvh.smai.repositories.InvestorRepository;
import com.uvh.smai.validations.InputValidation;


/**
 * 
 * @author Harika
 * Investor Service class.
 * Here we declare all the methods that are to be implemented.
 */
@Service
public class InvestorService {

	@Autowired
	InvestorRepository investorRepository;
	
	/**
	 * The method addInvestor adds a new investor to the investors table.
	 * @param investor
	 * @return
	 * @throws ResourceNotFoundException 
	 */
	public Investor addInvestor(Investor investor) throws ResourceNotFoundException {
		if( (InputValidation.name(investor.getInvestorName())) && 
				   (InputValidation.email(investor.getEmail())) && (InputValidation.mobileNo(investor.getMobileNo())))
			return investorRepository.save(investor);
		else
			throw new ResourceNotFoundException("Investor details are not valid. Please enter valid details."); 
		}
	
	/**
	 * The method getAllInvestors gets the list of all the investors from investor table. 
	 * @return
	 */
	public List<Investor> getAllInvestors() {
		return investorRepository.findAll();
	}
	
	/**
	 * The method getInvestorDetails gets all the details of a specified investor.
	 * @param investorId
	 * @return
	 * @throws InvalidIdException
	 */
	public Investor getInvestorDetails(int investorId) throws ResourceNotFoundException {
		Optional<Investor> investor = investorRepository.findById(investorId);
		if(investor.isPresent())
			return investor.get();
		else
			throw new ResourceNotFoundException("Investor details not found with the given id. Please enter a valid investor id");
	}
	
	/**
	 * The method updateInvestor updates all the details of a specified investor.
	 * @param info
	 * @return
	 * @throws InvalidInputException
	 */
	public Investor updateInvestor(Investor info) throws ResourceNotFoundException {
		if( (InputValidation.name(info.getInvestorName())) && 
				   (InputValidation.email(info.getEmail())) && (InputValidation.mobileNo(info.getMobileNo())))
			return investorRepository.save(info);
		else
			throw new ResourceNotFoundException("Entered details are not valid. Please enter valid details.");
	}
	
	/**
	 * The method deleteInvestor deletes a specified investor from the investors table.
	 * @param investorId
	 * @return
	 * @throws InvalidIdException
	 */
	public Investor deleteInvestor(int investorId) throws ResourceNotFoundException {
		Optional<Investor> investor = investorRepository.findById(investorId);
		if(investor.isPresent()) {
			investorRepository.deleteById(investorId);
			return investor.get();
			}
		else
			throw new ResourceNotFoundException("Investor with the given id is not found.");
	}
	
	@SuppressWarnings("unchecked")
	public List<Investor> viewAllInvestorCompany(String companyName) {
		return ((List<Investor>) investorRepository.findByCompanyName(companyName));
	}
	
	@SuppressWarnings("unchecked")
	public List<Investor> viewAllInvestorStock(String stockName) {
		return (List<Investor>) investorRepository.findByStockName(stockName);
	}
}
