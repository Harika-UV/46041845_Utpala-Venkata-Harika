package com.uvh.smai.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="company_info")
public class Company {
	
	@Id
	@GeneratedValue
	@Column(name = "company_id")
	private int companyId;
	
	@Column(name = "company_name")
	private String companyName;
	
	@Column(name ="no_of_stocks")
	private int noOfStocks;
	
	@Column(name = "stock_price")
	private double stockPrice;
		
	
	public Company() {
		
	}

	public Company(String companyName, int noOfStocks, double stockPrice) {
		super();
		this.companyName = companyName;
		this.noOfStocks = noOfStocks;
		this.stockPrice = stockPrice;
		}
	public Company(int companyId, String companyName,  int noOfStocks, double stockPrice) {
		super();
		this.companyId = companyId;
		this.companyName = companyName;
		
		this.noOfStocks = noOfStocks;
		this.stockPrice = stockPrice;
	}

	public int getCompanyId() {
		return companyId;
	}

	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public int getNoOfStocks() {
		return noOfStocks;
	}

	public void setNoOfStocks(int noOfStocks) {
		this.noOfStocks = noOfStocks;
	}

	public double getStockPrice() {
		return stockPrice;
	}

	public void setStockPrice(double stockPrice) {
		this.stockPrice = stockPrice;
	}

	@Override
	public String toString() {
		return "Company [companyId=" + companyId + ", companyName=" + companyName + ", noOfStocks=" + noOfStocks
				+ ", stockPrice=" + stockPrice + "]";
	}
	
}
