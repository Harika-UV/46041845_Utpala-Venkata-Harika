package com.uvh.smai;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import com.uvh.smai.repositories.InvestorRepository;

@SpringBootApplication
@ComponentScan(basePackages = "com.uvh.smai")
public class StockManagementAppInvestorApplication {

	public static void main(String[] args) {
		SpringApplication.run(StockManagementAppInvestorApplication.class, args);
	}
	
	@Autowired
	InvestorRepository investorRepository;

}
