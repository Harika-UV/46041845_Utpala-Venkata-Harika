package com.uvh.smai.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.uvh.smai.models.Company;
import com.uvh.smai.models.Investor;
import com.uvh.smai.models.Stock;

@Repository
public interface InvestorRepository extends JpaRepository<Investor, Integer> {

	@Query("SELECT i FROM Investor i WHERE i.company.companyName LIKE ?1% ")
	Investor findByCompanyName(@Param("name")String companyName);
	
	@Query("SELECT i FROM Investor i WHERE i.stock.stockName LIKE ?1% ")
	Investor findByStockName(@Param("name")String stockName);
}
