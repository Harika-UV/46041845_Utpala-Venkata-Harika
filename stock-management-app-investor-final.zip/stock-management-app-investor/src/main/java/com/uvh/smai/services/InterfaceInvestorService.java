package com.uvh.smai.services;

import java.util.List;

import com.uvh.smai.models.Company;
import com.uvh.smai.models.Investor;
import com.uvh.smai.models.Stock;

public interface InterfaceInvestorService {

	public Investor addInvestor(Investor info);
	public  List<Investor> getAllInvestor();
	public Investor getInvestorDetails(String investorId);
	public Investor  updateInvestor(Investor info);
	public Investor deleteInvestor(Investor inv);
	public List<Investor> viewAllInvestor(Stock stock);
	public List<Investor> viewAllInvestor(Company company);
}
