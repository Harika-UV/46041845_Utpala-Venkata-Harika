package com.uvh.smai.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "stock_info")
public class Stock {

	@Id
	@GeneratedValue
	@Column(name = "stock_id")
	private int stockId;
	
	@Column(name = "company_id")
	private int companyId;
	
	@Column(name = "investor_id")
	private int investorId;
	
	@Column(name = "stock_name")
	private String stockName;
	
	private int quantity;
	private String type;
	
	@Column(name = "avg_price")
	private double avgPrice;
	
	@Column(name = "total_no_of_stocks")
	private int totalNoOfStocks;
	
	@Column(name = "profit_loss")
	private double profitLoss;
	
	private String status;

	public Stock() {
		super();
	}

	public Stock(int companyId, int investorId, String stockName, int quantity, String type, double avgPrice,
			int totalNoOfStocks, double profitLoss, String status) {
		super();
		this.companyId = companyId;
		this.investorId = investorId;
		this.stockName = stockName;
		this.quantity = quantity;
		this.type = type;
		this.avgPrice = avgPrice;
		this.totalNoOfStocks = totalNoOfStocks;
		this.profitLoss = profitLoss;
		this.status = status;
	}

	public int getStockId() {
		return stockId;
	}

	public void setStockId(int stockId) {
		this.stockId = stockId;
	}

	public int getCompanyId() {
		return companyId;
	}

	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}

	public int getInvestorId() {
		return investorId;
	}

	public void setInvestorId(int investorId) {
		this.investorId = investorId;
	}

	public String getStockName() {
		return stockName;
	}

	public void setStockName(String stockName) {
		this.stockName = stockName;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public double getAvgPrice() {
		return avgPrice;
	}

	public void setAvgPrice(double avgPrice) {
		this.avgPrice = avgPrice;
	}

	public int getTotalNoOfStocks() {
		return totalNoOfStocks;
	}

	public void setTotalNoOfStocks(int totalNoOfStocks) {
		this.totalNoOfStocks = totalNoOfStocks;
	}

	public double getProfitLoss() {
		return profitLoss;
	}

	public void setProfitLoss(double profitLoss) {
		this.profitLoss = profitLoss;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "Stock [stockId=" + stockId + ", companyId=" + companyId + ", investorId=" + investorId + ", stockName="
				+ stockName + ", quantity=" + quantity + ", type=" + type + ", avgPrice=" + avgPrice
				+ ", totalNoOfStocks=" + totalNoOfStocks + ", profitLoss=" + profitLoss + ", status=" + status + "]";
	}
}
