package com.uvh.sma.service;

import java.util.List;

import com.uvh.sma.dao.InterfaceInvestorDAO;
import com.uvh.sma.dao.InvestorDAO;
import com.uvh.sma.dto.Company;
import com.uvh.sma.dto.Investor;
import com.uvh.sma.dto.Stock;
import com.uvh.sma.exceptions.InvalidException;

public class InvestorService implements InterfaceInvestorService {
	
	InterfaceInvestorDAO indao = new InvestorDAO();

	@Override
	public Investor addInvestor(Investor info) {
		
		return indao.addInvestor(info);
	}

	@Override
	public List<Investor> getAllInvestor() {
		
		return indao.getAllInvestor();
	}

	@Override
	public Investor getInvestorDetails(int investorId) throws InvalidException {
		
		return indao.getInvestorDetails(investorId);
	}

	@Override
	public Investor updateInvestor(Investor info) {
		
		return indao.updateInvestor(info);
	}

	@Override
	public Investor deleteInvestor(Investor inv) {
		
		return indao.deleteInvestor(inv);
	}

	@Override
	public List<Investor> viewAllInvestor(Stock stock) {
		
		return indao.viewAllInvestor(stock);
	}

	@Override
	public List<Investor> viewAllInvestor(Company company) {
		
		return indao.viewAllInvestor(company);
	}

}
