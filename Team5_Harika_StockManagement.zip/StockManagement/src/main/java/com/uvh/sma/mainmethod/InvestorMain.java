package com.uvh.sma.mainmethod;

//import com.uvh.sma.dto.BankAccount;
import com.uvh.sma.dto.Investor;
import com.uvh.sma.dto.Stock;
import com.uvh.sma.exceptions.InvalidException;
import com.uvh.sma.service.InvestorService;

public class InvestorMain {

	public static void main(String[] args) {
		
		InvestorService service = new InvestorService();
		//BankAccount account = new BankAccount(accountNo,branchName,bankName,ifscCode);
		Stock stock = new Stock();
		Investor info = new Investor(1, "Harika", "email", "password", "9876543201", "female", null);
		//info.setInvestorName("Harika");
		//info.setMobileNo("9876543201");
		//info.setGender("Female");
		service.addInvestor(info);
		System.out.println("Investor added :" + info);
		
		info = (Investor) service.getAllInvestor();
		System.out.println("All investors: " + info);
		
		try {
			info = service.getInvestorDetails(1);
		} catch (InvalidException e) {
			 System.out.println(e);
			e.printStackTrace();
		}
		
		info.setMobileNo("9837368190");
		info = service.updateInvestor(info);
		System.out.println("Updated details are " + info);
		
		//service.deleteInvestor(inv);
		
		//info = service.viewAllInvestor(stock);
		
		//info = service.viewAllInvestor(company);
	}

}
