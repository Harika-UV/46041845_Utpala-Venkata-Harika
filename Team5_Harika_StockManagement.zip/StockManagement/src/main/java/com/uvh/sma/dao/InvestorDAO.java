package com.uvh.sma.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.uvh.sma.dto.Company;
import com.uvh.sma.dto.Investor;
import com.uvh.sma.dto.Stock;
import com.uvh.sma.exceptions.InvalidException;

public class InvestorDAO implements InterfaceInvestorDAO {
	
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("InvestorUnit");
	EntityManager em = emf.createEntityManager();
	EntityTransaction tx = em.getTransaction();

	@Override
	public Investor addInvestor(Investor info) {
		tx.begin();
		em.persist(info);
		tx.commit();
		em.close();
		emf.close();
		return info;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Investor> getAllInvestor() {
		String selectQuery = "select i from Investor i";
		Query query = em.createQuery(selectQuery);
		List<Investor> list = query.getResultList();
		em.close();
		emf.close();
		return list;
	}

	@Override
	public Investor getInvestorDetails(int investorId) throws InvalidException {
		Investor investor = em.find(Investor.class, investorId);
		if(investor == null)
			throw new InvalidException("Investor details not found with the given id");
		em.close();
		emf.close();
		return investor;
	}

	@Override
	public Investor updateInvestor(Investor info) throws InvalidException {
		tx.begin();
		Investor investor = em.find(Investor.class,info.getInvestorId());
		if(investor == null)
			throw new InvalidException("Investor details not found with the given id");
		else {
			investor.setMobileNo(info.getMobileNo());
			tx.commit();
			em.close();
			emf.close();		
		}
		return investor;
	}

	@Override
	public Investor deleteInvestor(Investor inv) throws InvalidException{
		tx.begin();
		Investor investor = em.find(Investor.class,inv);
		if(investor == null)
			throw new InvalidException("Investor details not found with the given id");
		else {
			em.remove(investor);
			tx.commit();
			em.close();
			emf.close();
		}
		return investor;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Investor> viewAllInvestor(Stock stock) {
		String selectQuery = "select investor from Stock";
		Query query = em.createQuery(selectQuery);
		List<Investor> list = query.getResultList();
		em.close();
		emf.close();
		return list;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Investor> viewAllInvestor(Company company) {
		String selectQuery = "select investor from Company";
		Query query = em.createQuery(selectQuery);
		List<Investor> list = query.getResultList();
		em.close();
		emf.close();
		return list;
	}

}
