package com.uvh.sma.exceptions;

public class InvalidException extends Exception {
	public InvalidException(String msg) {
		super(msg);
	}
	
}
