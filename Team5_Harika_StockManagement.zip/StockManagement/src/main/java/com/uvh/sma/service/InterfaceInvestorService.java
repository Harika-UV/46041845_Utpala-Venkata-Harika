package com.uvh.sma.service;

import java.util.List;

import com.uvh.sma.dto.Company;
import com.uvh.sma.dto.Investor;
import com.uvh.sma.dto.Stock;
import com.uvh.sma.exceptions.InvalidException;

public interface InterfaceInvestorService {
	
	public Investor addInvestor(Investor info);
	public  List<Investor> getAllInvestor();
	public Investor getInvestorDetails(int investorId) throws InvalidException;
	public Investor updateInvestor(Investor info);
	public Investor deleteInvestor(Investor inv);
	public List<Investor> viewAllInvestor(Stock stock);
	public List<Investor> viewAllInvestor(Company company);
}
