package lab3;

public class Exercise2 {

	public static void main(String[] args ) {
		
		String str="fffkkkss";
		
		int k=str.length();
		for(int i=0;i<k;i++)
			
		{
	         char j=str.charAt(i);
		
			if(j=='a'||j=='e'||j=='i'||j=='o'||j=='u') {
				
				System.out.print(j);
		}
			else {
				char ch=  str.charAt(i);
				ch++;
				System.out.print(ch);
			
		}
		}
		
		
	}

}
