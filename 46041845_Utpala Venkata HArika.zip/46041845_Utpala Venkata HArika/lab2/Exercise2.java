/*package lab2;
import java.util.Arrays;
public class Exercise2 {
	public String sortStrings(String array) {
		char charArray[] = array.toCharArray();
		Arrays.sort(charArray);
		return String(charArray);
	}
} */
package lab2;
import java.util.Scanner;
import java.util.Arrays;
public class Exercise2 {
	public static void main(String[] args) {
		String[] names = new String[5];
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the names: ");
		for (int i=0;i<((names.length/2)+1 );i++ ) {
			names[i] = sc.next();
		}
		for(int i=((names.length/2)+1 );i<names.length;i++) {
			names[i]=sc.next();
	    }
		Arrays.sort(names);
		for (int i=0;i<names.length ;i++) {
			System.out.println("Name are " + names[i]);
		}
	}
}
