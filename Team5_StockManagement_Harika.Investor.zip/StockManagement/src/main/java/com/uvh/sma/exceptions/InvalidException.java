package com.uvh.sma.exceptions;

/**
 * @author Harika UV
 * InvalidException class extends Exception class.
 */
public class InvalidException extends Exception {
	public InvalidException(String msg) {
		super(msg);
	}
	
}
