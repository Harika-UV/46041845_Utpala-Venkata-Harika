package com.uvh.sma.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

/**
 * @author Harika UV
 * Creates a table with name stock in the database.
 */
@Entity
public class Stock {
	
	/**
	 *  Attributes
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "stock_id")
	private int stockId;
	@Column(name = "stock_name")
	private String stockName;
	@OneToOne
	@JoinColumn(name = "investorId")
	private Investor investor;
	
	/**
	 *  Constructors  
	 */
	public Stock() {
		super();
	}

	public Stock(int stockId, String stockName, Investor investor) {
		super();
		this.stockId = stockId;
		this.stockName = stockName;
		this.investor = investor;
	}
	
	/**
	 *  Getters and Setters
	 */
	public int getStockId() {
		return stockId;
	}

	public void setStockId(int stockId) {
		this.stockId = stockId;
	}

	public String getStockName() {
		return stockName;
	}

	public void setStockName(String stockName) {
		this.stockName = stockName;
	}

	public Investor getInvestor() {
		return investor;
	}

	public void setInvestor(Investor investor) {
		this.investor = investor;
	}
	
	/**
	 *  toString
	 */
	@Override
	public String toString() {
		return "Stock [stockId=" + stockId + ", stockName=" + stockName + ", investor=" + investor + "]";
	}
}
