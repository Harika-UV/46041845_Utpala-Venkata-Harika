package com.uvh.sma.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.uvh.sma.dto.Company;
import com.uvh.sma.dto.Investor;
import com.uvh.sma.dto.Stock;
import com.uvh.sma.exceptions.InvalidException;

/**
 * @author Harika UV
 * InvestorDAO class implements InterfaceInvestorDAO interface.
 */
public class InvestorDAO implements InterfaceInvestorDAO {
	
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("InvestorUnit");
	EntityManager em = emf.createEntityManager();
	EntityTransaction tx = em.getTransaction();

	/**
	 * Method Name : addInvestor(Investor info)
	 * Input Parameters : Investor info
	 * Return Type : Investor
	 * Author : Harika UV  
	 * Description : Adding investor to database
	 */	
	@Override
	public Investor addInvestor(Investor info) {
		tx.begin();
		em.persist(info);
		tx.commit();
		em.close();
		emf.close();
		return info;
	}
	
	/**
	 * Method Name : getAllInvestor()
	 * Return Type : List<Investor>
	 * Author : Harika UV  
	 * Description : Getting all the investors from database
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<Investor> getAllInvestor() {
		String selectQuery = "select i from Investor i";
		Query query = em.createQuery(selectQuery);
		List<Investor> list = query.getResultList();
		em.close();
		emf.close();
		return list;
	}
	
	/**
	 * Method Name : getInvestorDetails(int investorId)
	 * Input Parameters : int investorId
	 * Return Type : int
	 * Throws : InvalidException
	 * Author : Harika UV  
	 * Description : Getting investor details from database
	 */
	@Override
	public Investor getInvestorDetails(int investorId) throws InvalidException {
		Investor investor = em.find(Investor.class, investorId);
		if(investor == null)
			throw new InvalidException("Investor details not found with the given id");
		em.close();
		emf.close();
		return investor;
	}
	
	/**
	 * Method Name : updateInvestor(Investor info)
	 * Input Parameters : Investor info
	 * Return Type : Investor
	 * Throws : InvalidException
	 * Author : Harika UV  
	 * Description : Updating investor in database
	 */
	@Override
	public Investor updateInvestor(Investor info) throws InvalidException {
		tx.begin();
		Investor investor = em.find(Investor.class,info.getInvestorId());
		if(investor == null)
			throw new InvalidException("Investor details not found with the given id");
		else {
			investor.setMobileNo(info.getMobileNo());
			tx.commit();
			em.close();
			emf.close();		
		}
		return investor;
	}
	
	/**
	 * Method Name : deleteInvestor(Investor inv)
	 * Input Parameters : Investor inv
	 * Return Type : Investor
	 * Throws : InvalidException
	 * Author : Harika UV  
	 * Description : Deleting investor from database
	 */
	@Override
	public Investor deleteInvestor(Investor inv) throws InvalidException {
		tx.begin();
		Investor investor = em.find(Investor.class,inv);
		if(investor == null)
			throw new InvalidException("Investor details not found with the given id");
		else {
			em.remove(investor);
			tx.commit();
			em.close();
			emf.close();
		}
		return investor;
	}
	
	/**
	 * Method Name : viewAllInvestor(Stock stock)
	 * Input Parameters : Stock stock
	 * Return Type : List<Investor>
	 * Author : Harika UV  
	 * Description : Viewing all the investors in database
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<Investor> viewAllInvestor(Stock stock) {
		String selectQuery = "select investor from Stock";
		Query query = em.createQuery(selectQuery);
		List<Investor> list = query.getResultList();
		em.close();
		emf.close();
		return list;
	}
	
	/**
	 * Method Name : viewAllInvestor(Company company)
	 * Input Parameters : Company company
	 * Return Type : List<Investor>
	 * Author : Harika UV  
	 * Description : Viewing all the investors in database
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<Investor> viewAllInvestor(Company company) {
		String selectQuery = "select investor from Company";
		Query query = em.createQuery(selectQuery);
		List<Investor> list = query.getResultList();
		em.close();
		emf.close();
		return list;
	}

}
