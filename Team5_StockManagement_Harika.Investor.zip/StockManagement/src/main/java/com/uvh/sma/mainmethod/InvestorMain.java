package com.uvh.sma.mainmethod;

import com.uvh.sma.dto.BankAccount;
import com.uvh.sma.dto.Company;
import com.uvh.sma.dto.Investor;
import com.uvh.sma.dto.Stock;
import com.uvh.sma.exceptions.InvalidException;
import com.uvh.sma.service.InvestorService;

/**
 * @author Harika UV
 * Class InvestorMain that contains the main method.
 *
 */
public class InvestorMain {

	public static void main(String[] args) {
		
		InvestorService service = new InvestorService();
		BankAccount account = new BankAccount();
		Stock stock = new Stock();
		Company company = new Company();
		
		/**
		 * Adds investor to the database.
		 */
		Investor info = new Investor(1, "Harika", "harika@gmail.com", "password", "9876543201", "female", account);
		service.addInvestor(info);
		System.out.println("Investor added :" + info);
		
		/**
		 * Gets all investors from the database.
		 */
		info = (Investor) service.getAllInvestor();
		System.out.println("All investors: " + info);
		
		/**
		 * Gets all the investor details from the database.
		 */
		try {
			info = service.getInvestorDetails(1);
			System.out.println("Investor details: " + info);
		} catch (InvalidException e) {
			 System.out.println(e);
		}
			
		/**
		 * Updates the details of the investor in the database.
		 */
		info.setMobileNo("9837368190");
		try {
			info = service.updateInvestor(info);
			System.out.println("Updated details are " + info);
		} catch (InvalidException e) {
			System.out.println(e);
		}
		
		/**
		 * Deletes the investor from the database.
		 */
		Investor inv = new Investor();
		try {
			service.deleteInvestor(inv);
			System.out.println("Investor deleted: " + inv);
		} catch (InvalidException e) {
			System.out.println(e);
		}
		
		/**
		 * Views all the investors in the database that are connected with stock table.
		 */
		info = (Investor) service.viewAllInvestor(stock);
		System.out.println("Viewing all the investors: " + info);
		
		/**
		 * Views all the investors in the database that are connected with company table.
		 */
		info = (Investor) service.viewAllInvestor(company);
		System.out.println("Viewing all the investors: " + info);
	}

}
