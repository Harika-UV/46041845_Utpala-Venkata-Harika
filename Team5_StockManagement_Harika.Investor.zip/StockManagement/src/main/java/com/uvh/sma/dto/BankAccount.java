package com.uvh.sma.dto;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 * @author Harika UV
 */
public class BankAccount {
	
	/**
	 *  Attributes
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "account_no")
	private long accountNo;
	@Column(name = "branch_name")
	private String branchName;
	@Column(name = "bank_name")
	private String bankName;
	@Column(name = "ifsc_code")
	private String ifscCode;
	
	/**
	 *  Constructors  
	 */
	public BankAccount() {
		super();
	}

	public BankAccount(long accountNo, String branchName, String bankName, String ifscCode) {
		super();
		this.accountNo = accountNo;
		this.branchName = branchName;
		this.bankName = bankName;
		this.ifscCode = ifscCode;
	}
	
	/**
	 *  Getters and Setters
	 */
	public long getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
	
	/**
	 *  toString
	 */
	@Override
	public String toString() {
		return "BankAccount [accountNo=" + accountNo + ", branchName=" + branchName + ", bankName=" + bankName
				+ ", ifscCode=" + ifscCode + "]";
	}
}
