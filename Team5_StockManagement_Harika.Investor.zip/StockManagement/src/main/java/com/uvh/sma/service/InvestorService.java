package com.uvh.sma.service;

import java.util.List;

import com.uvh.sma.dao.InterfaceInvestorDAO;
import com.uvh.sma.dao.InvestorDAO;
import com.uvh.sma.dto.Company;
import com.uvh.sma.dto.Investor;
import com.uvh.sma.dto.Stock;
import com.uvh.sma.exceptions.InvalidException;

/**
 * @author Harika UV
 * InvestorService class implements InterfaceInvestorService interface.
 */
public class InvestorService implements InterfaceInvestorService {
	
	InterfaceInvestorDAO indao = new InvestorDAO();

	/**
	 * Method Name : addInvestor(Investor info)
	 * Input Parameters : Investor info
	 * Return Type : Investor
	 * Author : Harika UV  
	 * Description : Calls dao method addInvestor(info)
	 */	
	@Override
	public Investor addInvestor(Investor info) {
		
		return indao.addInvestor(info);
	}

	/**
	 * Method Name : getAllInvestor()
	 * Return Type : List<Investor>
	 * Author : Harika UV  
	 * Description : Calls dao method getAllInvestor()
	 */	
	@Override
	public List<Investor> getAllInvestor() {
		
		return indao.getAllInvestor();
	}
	
	/**
	 * Method Name : getInvestorDetails(int investorId)
	 * Input Parameters : int investorId
	 * Return Type : int
	 * Throws : InvalidException
	 * Author : Harika UV  
	 * Description : Calls dao method getInvestorDetails(investorId)
	 */
	@Override
	public Investor getInvestorDetails(int investorId) throws InvalidException {
		
		return indao.getInvestorDetails(investorId);
	}
	
	/**
	 * Method Name : updateInvestor(Investor info)
	 * Input Parameters : Investor info
	 * Return Type : Investor
	 * Throws : InvalidException
	 * Author : Harika UV  
	 * Description : Calls dao method updateInvestor(info)
	 */
	@Override
	public Investor updateInvestor(Investor info) throws InvalidException {
		
		return indao.updateInvestor(info);
	}
	
	/**
	 * Method Name : deleteInvestor(Investor inv)
	 * Input Parameters : Investor inv
	 * Return Type : Investor
	 * Throws : InvalidException
	 * Author : Harika UV  
	 * Description : Calls dao method deleteInvestor(inv)
	 */
	@Override
	public Investor deleteInvestor(Investor inv) throws InvalidException {
		
		return indao.deleteInvestor(inv);
	}
	
	/**
	 * Method Name : viewAllInvestor(Stock stock)
	 * Input Parameters : Stock stock
	 * Return Type : List<Investor>
	 * Author : Harika UV  
	 * Description : Calls dao method viewAllInvestor(stock)
	 */
	@Override
	public List<Investor> viewAllInvestor(Stock stock) {
		
		return indao.viewAllInvestor(stock);
	}
	
	/**
	 * Method Name : viewAllInvestor(Company company)
	 * Input Parameters : Company company
	 * Return Type : List<Investor>
	 * Author : Harika UV  
	 * Description : Calls dao method viewAllInvestor(company)
	 */
	@Override
	public List<Investor> viewAllInvestor(Company company) {
		
		return indao.viewAllInvestor(company);
	}

}
