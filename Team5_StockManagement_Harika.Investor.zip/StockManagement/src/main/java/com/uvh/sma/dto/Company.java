package com.uvh.sma.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 * @author Harika UV
 * Creates a table with name company in the database.
 */
@Entity
public class Company {

	/**
	 *  Attributes
	 */	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "company_id")
	private int companyId;
	@Column(name = "company_name")
	private String companyName;
	private Company company;
	private int quantity;
	private String type;
	@Column(name = "avg_price")
	private double avgPrice;
	@Column(name = "total_stocks")
	private int totalStocks;
	@Column(name = "profit_loss")
	private double profitLosss;
	private String status;
	
	/**
	 *  Constructors  
	 */
	public Company() {
		super();
	}

	public Company(int companyId, String companyName, Company company, int quantity, String type, double avgPrice,
			int totalStocks, double profitLosss, String status) {
		super();
		this.companyId = companyId;
		this.companyName = companyName;
		this.company = company;
		this.quantity = quantity;
		this.type = type;
		this.avgPrice = avgPrice;
		this.totalStocks = totalStocks;
		this.profitLosss = profitLosss;
		this.status = status;
	}
	
	/**
	 *  Getters and Setters
	 */
	public int getCompanyId() {
		return companyId;
	}

	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public Company getCompany() {
		return company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public double getAvgPrice() {
		return avgPrice;
	}

	public void setAvgPrice(double avgPrice) {
		this.avgPrice = avgPrice;
	}

	public int getTotalStocks() {
		return totalStocks;
	}

	public void setTotalStocks(int totalStocks) {
		this.totalStocks = totalStocks;
	}

	public double getProfitLosss() {
		return profitLosss;
	}

	public void setProfitLosss(double profitLosss) {
		this.profitLosss = profitLosss;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	/**
	 *  toString
	 */
	@Override
	public String toString() {
		return "Company [companyId=" + companyId + ", companyName=" + companyName + ", company=" + company
				+ ", quantity=" + quantity + ", type=" + type + ", avgPrice=" + avgPrice + ", totalStocks="
				+ totalStocks + ", profitLosss=" + profitLosss + ", status=" + status + "]";
	}
}
