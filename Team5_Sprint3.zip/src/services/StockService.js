import axios from 'axios';

//import http from"../http-common";
 const EMPLOYEE_API_BASE_URL = "http://localhost:4000/stk";

class StockService {

   

    viewAllStockDetails(){
        return axios.get(EMPLOYEE_API_BASE_URL +'/Stock' );
       //return http.get("/admins");
    }

    addStockDetails(stock){
        return axios.post(EMPLOYEE_API_BASE_URL+'/Stock' ,stock );
        //return http.post("/admins", admin);
    }

    viewStockDetails(stockId){
       return axios.get(EMPLOYEE_API_BASE_URL +'/Stockv/'+stockId);
      // return http.get(`/admins/${id}`);
    }

    updateStockDetails(stockId,stock){
        return axios.put(EMPLOYEE_API_BASE_URL +`/Stock/${stockId}`,stock);
       //return http.put(`/admins/${id}`, admin);
    }

    removeStockDetails(stockId){
        return axios.delete(EMPLOYEE_API_BASE_URL  + '/Stock/'+stockId);
       //return http.delete(`/admins/${id}`);
    }
}


export default new StockService()