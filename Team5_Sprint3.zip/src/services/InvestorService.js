import axios from 'axios';

const INVESTOR_API_BASE_URL = "http://localhost:4000/inv";

class InvestorService {

    getAllInvestors(){
        return axios.get(INVESTOR_API_BASE_URL +'/investors');
    }

    addInvestor(investor){
        return axios.post(INVESTOR_API_BASE_URL +'/investors', investor);
    }

    getInvestorDetails(investorId){
        return axios.get(INVESTOR_API_BASE_URL +'/investors/'+investorId);
    }

    updateInvestor(investor,investorId){
        return axios.put(INVESTOR_API_BASE_URL +`/${investorId}`,investor);
    }

    deleteInvestor(investorId){
        return axios.delete(INVESTOR_API_BASE_URL + '/investors/' + investorId);
    }
}
export default new InvestorService();