import axios from 'axios';

const MANAGER_API_BASE_URL = "http://localhost:4000/mana";

class ManagerService {

    getAllManagerInfo(){
        return axios.get(MANAGER_API_BASE_URL +'/managers');
    }

    addManagerInfo(manager){
        return axios.post(MANAGER_API_BASE_URL +'/managers', manager);
    }

    getManagerDetails(managerId){
        return axios.get(MANAGER_API_BASE_URL +'/managers/'+managerId);
    }

    updateManagerInfo(managerId,manager){
        return axios.put(MANAGER_API_BASE_URL +`/managers/${managerId}` ,manager);
    }

    deleteManagerInfo(managerId){
        return axios.delete(MANAGER_API_BASE_URL + '/managers/' + managerId);
    }
}
export default new ManagerService();