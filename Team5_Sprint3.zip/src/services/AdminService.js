import axios from 'axios';

//import http from"../http-common";
 const EMPLOYEE_API_BASE_URL = "http://localhost:4000/api/v1";

class AdminService {

   

    getAllAdmin(){
        return axios.get(EMPLOYEE_API_BASE_URL +'/admins' );
       //return http.get("/admins");
    }

    insertAdmin(admin){
        return axios.post(EMPLOYEE_API_BASE_URL+'/' ,admin );
        //return http.post("/admins", admin);
    }

    getAdminById(id){
       return axios.get(EMPLOYEE_API_BASE_URL +'/'+id);
      // return http.get(`/admins/${id}`);
    }

    updateAdmin(admin,id){
        return axios.put(EMPLOYEE_API_BASE_URL +'/'+id,admin);
       //return http.put(`/admins/${id}`, admin);
    }

    deleteAdmin(id){
        return axios.delete(EMPLOYEE_API_BASE_URL  + '/'+id);
       //return http.delete(`/admins/${id}`);
    }
}


export default new AdminService()