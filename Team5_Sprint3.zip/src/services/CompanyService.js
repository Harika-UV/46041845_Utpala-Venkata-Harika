import axios from 'axios';

const COMPANY_API_BASE_URL = "http://localhost:4000/comp";

class CompanyService {

    getAllCompanyInfo(){
        return axios.get(COMPANY_API_BASE_URL+'/companies');
    }

    addCompanyInfo(company){
        return axios.post(COMPANY_API_BASE_URL+'/companies', company);
    }

    getCompanyDetails(companyId){
        return axios.get(COMPANY_API_BASE_URL +'/companies/'+companyId);
    }

    updateCompanyInfo(companyId,company){
        return axios.put(COMPANY_API_BASE_URL +`/companies/${companyId}`,company);
    }

    deleteCompanyInfo(companyId){
        return axios.delete(COMPANY_API_BASE_URL + '/companies/' + companyId);
    }
}
export default new CompanyService();