import React, { Component } from 'react'
import StockService from '../services/StockService';
 class UpdateStockComponent extends Component {
     constructor(props)
     {
         super(props)
         this.state={
            stockId:this.props.match.params.stockId,
             stockName:'',
             quantity:'',
             type:'',
             avgPrice:'',
             totalNoOfStocks:'',
             profitLoss:'',
             status:''
         }
         this.changeStockNameHandler=this.changeStockNameHandler.bind(this);
         this.changeQuantityHandler=this.changeQuantityHandler.bind(this);
         this.changeTypeHandler=this.changeTypeHandler.bind(this);
         this.changeAvgPriceHandler=this.changeAvgPriceHandler.bind(this);
         this.changeTotalNoOfStocksHandler=this.changeTotalNoOfStocksHandler.bind(this);
         this.changeProfitLossHandler=this.changeProfitLossHandler.bind(this);
         this.changeStatusHandler=this.changeStatusHandler.bind(this);
         this.updateStock=this.updateStock.bind(this);
     }
     changeStockNameHandler= (event)=>{
         this.setState({stockName: event.target.value});
     }
     changeQuantityHandler= (event)=>{
        this.setState({quantity: event.target.value});
    }
    changeTypeHandler= (event)=>{
        this.setState({type: event.target.value});
    }
    changeAvgPriceHandler= (event)=>{
        this.setState({avgPrice: event.target.value});
    }
    changeTotalNoOfStocksHandler= (event)=>{
        this.setState({totalNoOfStocks: event.target.value});
    }
    changeProfitLossHandler= (event)=>{
        this.setState({profitLoss: event.target.value});
    }
    changeStatusHandler=(event)=>{
        this.setState({status: event.target.value});
    }
    componentDidMount()
    {
        StockService.viewStockDetails(this.state.StockId).then((res) =>{
            let stock=res.data;
           this.setState({ stockName: stock.stockName,quantity:stock.quantity,type:stock.type,avgPrice:stock.avgPrice,totalNoOfStocks:stock.totalNoOfStocks,profitLoss:stock.profitLoss,status:stock.status})
        });
    }
     updateStock =(e) =>{
         e.preventDefault();
         let stock ={stockId:this.state.stockId,stockName: this.state.stockName,quantity:this.state.quantity,type:this.state.type,avgPrice:this.state.avgPrice,totalNoOfStocks:this.state.totalNoOfStocks,profitLoss:this.state.profitLoss,status:this.state.status};
         console.log('stock => '+JSON.stringify(stock));
         StockService.updateStockDetails(this.state.stockId,stock).then(res =>{
             this.props.history.push('/stocks');

         });
     }
     
     cancel(){
        this.props.history.push('/stocks');
     }

    render() {
        return (
            <div>
                <div className="container">
                    <div className="row">
                        <div className="card col-md-6 offset-md-3 offset=md-3"></div>
                        <h2 className="text-center">Update Stock</h2>
                        <div className="card-body">
                            <form>
                                <div className="form-group">
                                    <label>Stock Name</label>
                                    <input placeholder="Stock Name" name="stockName" className="form-control"
                                    value={this.state.stockName} onChange={this.changeStockNameHandler}></input>
                                </div>
                                <div className="form-group">
                                    <label>Quantity</label>
                                    <input placeholder="Quantity" name="quantity" className="form-control"
                                    value={this.state.quantity} onChange={this.changeQuantityHandler}></input>
                                </div>
                                <div className="form-group">
                                    <label>Type</label>
                                    <input placeholder="Type" name="type" className="form-control"
                                    value={this.state.type} onChange={this.changeTypeHandler}></input>
                                </div>
                                <div className="form-group">
                                    <label>AvgPrice</label>
                                    <input placeholder="AvgPrice" name="avgPrice" className="form-control"
                                    value={this.state.avgPrice} onChange={this.changeAvgPriceHandler}></input>
                                </div>
                                <div className="form-group">
                                    <label>TotalNoOfStocks</label>
                                    <input placeholder="TotalNoOfStocks" name="totalNoOfStocks" className="form-control"
                                    value={this.state.totalNoOfStocks} onChange={this.changeTotalNoOfStocksHandler}></input>
                                </div>
                                <div className="form-group">
                                    <label> profitLoss</label>
                                    <input placeholder=" ProfitLoss" name="profitLoss" className="form-control"
                                    value={this.state.profitLoss} onChange={this.changeProfitLossHandler}></input>
                                </div>
                                <div className="form-group">
                                    <label> Status</label>
                                    <input placeholder=" Status" name="status" className="form-control"
                                    value={this.state.status} onChange={this.changeStatusHandler}></input>
                                </div>
                                <button className="btn btn-success" onClick={this.updateStock}>Save</button>
                                <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft: "10px"}}>Cancel</button>
                            </form>
                        </div>
                    </div>
                    
                </div>
                
            </div>
        )
    }
}
export default UpdateStockComponent