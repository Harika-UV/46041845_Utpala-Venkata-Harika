import React, { Component } from 'react'
import ManagerService from '../services/ManagerService';
 class UpdateManagerComponent extends Component {
     constructor(props)
     {
         super(props)
         this.state={
             managerId:this.props.match.params.managerId,
             managerName:'',
             email:'',
             mobileNo:''
        }

         this.changeManagerNameHandler=this.changeManagerNameHandler.bind(this);
         this.changeEmailHandler=this.changeEmailHandler.bind(this);
         this.changeMobileNoHandler=this.changeMobileNoHandler.bind(this);
         this.updateManager=this.updateManager.bind(this);
     }

     componentDidMount(){
        ManagerService.getManagerDetails(this.state.managerId).then(res=>{

            //console.log(this.state.managerId);
            let manager=res.data;
            this.setState({managerName:manager.managerName,email:manager.email,mobileNo:manager.mobileNo});
        });
     }

     changeManagerNameHandler= (event)=>{
         this.setState({managerName: event.target.value});
     }

     changeEmailHandler= (event)=>{
        this.setState({email: event.target.value});
    }

    changeMobileNoHandler= (event)=>{
        this.setState({mobileNo: event.target.value});
    }

     updateManager =(e) =>{
         e.preventDefault();
         let manager ={managerId:this.state.managerId,managerName: this.state.managerName,email:this.state.email,mobileNo:this.state.mobileNo};
         console.log('manager => '+JSON.stringify(manager));
         //console.log(this.state.managerId);
         ManagerService.updateManagerInfo(this.state.managerId,manager).then(res =>{
             this.props.history.push('/managers');
        });
     }
     
     cancel(){
        this.props.history.push('/managers');
     }

    render() {
        return (
            <div>
                <div className="container">
                    <div className="row">
                        <div className="card col-md-6 offset-md-3 offset=md-3"></div>
                        <h2 className="text-center">Update Manager</h2>
                        <div className="card-body">
                            <form>
                                <div className="form-group">
                                    <label>Manager Name</label>
                                    <input placeholder="Manager Name" name="managerName" className="form-control"
                                    value={this.state.managerName} onChange={this.changeManagerNameHandler}></input>
                                </div>
                                <div className="form-group">
                                    <label>Email</label>
                                    <input placeholder="Email" name="email" className="form-control"
                                    value={this.state.email} onChange={this.changeEmailHandler}></input>
                                </div>
                                <div className="form-group">
                                    <label>Mobile No</label>
                                    <input placeholder="Mobile No" name="mobileNo" className="form-control"
                                    value={this.state.mobileNo} onChange={this.changeMobileNoHandler}></input>
                                </div>
                                <button className="btn btn-success" onClick={this.updateManager}>Save</button>
                                <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft: "10px"}}>Cancel</button>
                            </form>
                        </div>
                    </div>
                    
                </div>
                
            </div>
        )
    }
}
export default UpdateManagerComponent