import React, { useState } from 'react';
import './Nav.css';
import {Link} from 'react-router-dom';
import DropDown from './DropDown';

function Nav() {
  const [click, setClick] = useState(false);
  const [dropdown, setDropdown] = useState(false);

  const handleClick = () => setClick(!click);
  const closeMobileMenu = () => setClick(false);

  const onMouseEnter = () => {
    if(window.innerWidth < 960) {
      setDropdown(false)
    }
    else {
      setDropdown(true)
    }
  }

  const onMouseLeave = () => {
    if(window.innerWidth < 960) {
      setDropdown(false)
    }
    else {
      setDropdown(false)
    }
  }
  
  return (
    <nav className="navbar">
      {/*<h1 className="navbar-logo">Stock Exchange Application</h1> */}
      <Link to='/' className="navbar-logo" onClick={closeMobileMenu}>Stock Exchange Application</Link>
      <div className="menu-icon" onClick={handleClick}>
        <i className={click ? 'fas fa-times' : 'fas fa-bars'} />
      </div>
      <ul className={click ? 'nav-menu active' : 'nav-menu'}>
        <li className="nav-item"> 
          <Link to='/' className="nav-links" onClick={closeMobileMenu}Home></Link>
        </li> 
        <li className="nav-item"> 
          <Link to='/about' className="nav-links" onClick={closeMobileMenu}>About</Link>
        </li> 
        <li className="nav-item"> 
          <Link to='/login' className="nav-links" onClick={closeMobileMenu}>Login</Link>
        </li> 
        <li className="nav-item"> 
          <Link to='/signup' className="nav-links" onClick={closeMobileMenu}>Signup</Link>
        </li>      
        <li className="nav-item" onMouseEnter={onMouseEnter} onMouseLeave={onMouseLeave}> 
          <Link to='/modules' className="nav-links" >
            Modules <i className='fas fa-caret-down' />
          </Link>
          {dropdown && <DropDown />}
        </li>      
      </ul>
      </nav>
    )
  }

export default Nav;
