import React, { Component } from 'react'
import StockService from '../services/StockService'

class ListStockComponent extends Component {
    constructor(props) {
        super(props)
        this.state = {
           stocks: []

        }
        this.viewStock=this.viewStock.bind(this);
        this.editStock=this.editStock.bind(this);
        this.addStock = this.addStock.bind(this);
        this.deleteStock = this.deleteStock.bind(this);
    }
    componentDidMount() {
        StockService.viewAllStockDetails().then((res) => {
            this.setState({ stocks: res.data })

        });
    }
    editStock(stockId)
    {
        this.props.history.push(`/edit-stock/${stockId}`)

    }
    addStock() {
        this.props.history.push('/add-stock');
    }
    deleteStock(stockId) {
        StockService.removeStockDetails(stockId).then(res => {
                this.setState({ stocks: this.state.stocks.filter(stock => stock.stockId !== stockId) });

            });
    }
    viewStock(stockId)
     {
         this.props.history.push(`/view-stock/${stockId}`);
     }
    render() {
        return (
            <div>
                <h2 className="text-center">Stock List</h2>
                <div className="row">
                    <button className="btn btn-primary" onClick={this.addStock}>Add Stock</button>
                    <table className="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>StockName</th>
                                <th>Quantity</th>
                                <th>Type</th>
                                <th>Average Price</th>
                                <th>TotalNoOfStocks</th>
                                <th>ProfitLoss</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                this.state.stocks.map(
                                  stock =>
                                        <tr key={stock.stockId}>
                                            <td>{stock.stockName}</td>
                                            <td>{stock.quantity}</td>
                                            <td>{stock.type}</td>
                                            <td>{stock.avgPrice}</td>
                                            <td>{stock.totalNoOfStocks}</td>
                                            <td>{stock.profitLoss}</td>
                                            <td>{stock.status}</td>

                                            
                                            <td>
                                                <button onClick = {()=> this.editStock(stock.stockId)} className="btn btn-info">Update</button>
                                                <button style={{ marginLeft: "10px" }} onClick={() => this.deleteStock(stock.stockId)} className="btn btn-danger">Delete</button>
                                                <button style={{ marginLeft: "10px" }} onClick={() => this.viewStock(stock.stockId)} className="btn btn-info">View</button>


                                            </td>

                                        </tr>
                                )
                            }
                        </tbody>

                    </table>
                </div>

            </div>
        )
    }
}
export default ListStockComponent