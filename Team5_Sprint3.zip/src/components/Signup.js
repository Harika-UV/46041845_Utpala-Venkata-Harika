import React from 'react';
// import'./App.css';
// import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
// import './Signup.css';

function Signup() {
  return (
    <div>
      {/* <h>Login Page</h3> */}
      <div class="container">
      <div class="forms-container">
        <div class="signin-signup"></div>
          <form action="#" className="sign-up-form">
                <h2 className="title">Sign up</h2>
                <div className="input-field">
                  <i className="fas fa-user"></i>
                  {/* <FontAwesomeIcon icon={['fas', 'user']} /> */}
                  <input type="text" placeholder="Username" />
                </div>
                <div className="input-field">
                  <i class="fas fa-lock"></i>
                  <input type="password" placeholder="Password" />
                </div>
                <input type="submit" className="btn solid" value="Signup" />
          </form>
        </div>
      </div>
    </div>
  );
}

export default Signup;
