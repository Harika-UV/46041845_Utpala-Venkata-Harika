import React, { Component } from 'react'
import InvestorService from '../services/InvestorService';
 class AddInvestorComponent extends Component {
     constructor(props)
     {
         super(props)
         this.state={
            investorName:'',
            email:'',
            password:'',
            mobileNo :'',
            gender:''
             
         }
         this.changeInvestorNameHandler=this.changeInvestorNameHandler.bind(this);
         this.changeEmailHandler=this.changeEmailHandler.bind(this);
         this.changeMobileNoHandler=this.changeMobileNoHandler.bind(this);
         this.changePasswordHandler=this.changePasswordHandler.bind(this);
         this.changeGenderHandler=this.changeGenderHandler.bind(this);
         this.saveInvestor=this.saveInvestor.bind(this);
     }

     changeInvestorNameHandler= (event)=>{
         this.setState({investorName: event.target.value});
     }

     changeEmailHandler= (event)=>{
        this.setState({email: event.target.value});
    }

    changeMobileNoHandler= (event)=>{
        this.setState({mobileNo: event.target.value});
    }

    changePasswordHandler= (event)=>{
        this.setState({password: event.target.value});
    }
    changeGenderHandler= (event)=>{
        this.setState({gender: event.target.value});
    }
     saveInvestor =(e) =>{
         e.preventDefault();
         let investor ={investorName: this.state.investorName,email:this.state.email,mobileNo:this.state.mobileNo,
                        password:this.state.password,gender:this.state.gender};
         console.log('investor => '+JSON.stringify(investor));
         InvestorService.addInvestor(investor).then(res =>{
             this.props.history.push('/investors');

         });
     }
     
     cancel(){
        this.props.history.push('/investors');
     }

    render() {
        return (
            <div>
                <div className="container">
                    <div className="row">
                        <div className="card col-md-6 offset-md-3 offset=md-3"></div>
                        <h2 className="text-center">Add Investor</h2>
                        <div className="card-body">
                            <form>
                                <div className="form-group">
                                    <label>Investor Name</label>
                                    <input placeholder="Investor Name" name="investorName" className="form-control"
                                    value={this.state.investorName} onChange={this.changeInvestorNameHandler}></input>
                                </div>
                                <div className="form-group">
                                    <label>Email</label>
                                    <input placeholder="Email" name="email" className="form-control"
                                    value={this.state.email} onChange={this.changeEmailHandler}></input>
                                </div>
                                <div className="form-group">
                                    <label>Mobile No</label>
                                    <input placeholder="Mobile No" name="mobileNo" className="form-control"
                                    value={this.state.mobileNo} onChange={this.changeMobileNoHandler}></input>
                                </div>
                                <div className="form-group">
                                    <label>Gender</label>
                                    <input placeholder="Gender" name="gender" className="form-control"
                                    value={this.state.gender} onChange={this.changeGenderHandler}></input>
                                </div>
                                <div className="form-group">
                                    <label>Password</label>
                                    <input type="password" placeholder="Password" name="password" className="form-control"
                                    value={this.state.password} onChange={this.changePasswordHandler}></input>
                                </div>
                                <button className="btn btn-success" onClick={this.saveInvestor}>Save</button>
                                <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft: "10px"}}>Cancel</button>
                            </form>
                        </div>
                    </div>
                    
                </div>
                
            </div>
        )
    }
}
export default AddInvestorComponent