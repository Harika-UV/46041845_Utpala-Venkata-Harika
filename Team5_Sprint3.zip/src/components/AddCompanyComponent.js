import React, { Component } from 'react'
import CompanyService from '../services/CompanyService';
 class AddCompanyComponent extends Component {
     constructor(props)
     {
         super(props)
         this.state={
             companyName:'',
            /* manager:{
             managerName:'',
             email:'',
             mobileNo:''
             },*/
             noOfStocks:'',
             stockPrice:'',
             percentageChange:''
            
        }

         this.changeCompanyNameHandler=this.changeCompanyNameHandler.bind(this);
         //this.changeManagerNameHandler=this.changeManagerNameHandler.bind(this);
         //this.changeEmailHandler=this.changeEmailHandler.bind(this);
         //this.changeMobileNoHandler=this.changeMobileNoHandler.bind(this);
         this.changeNoOfStocksHandler=this.changeNoOfStocksHandler.bind(this);
         this.changeStockPriceHandler=this.changeStockPriceHandler.bind(this);
         this.changePercentageChangeHandler=this.changePercentageChangeHandler.bind(this);
         this.saveCompany=this.saveCompany.bind(this);
     }

     changeCompanyNameHandler= (event)=>{
        this.setState({companyName: event.target.value});
    }

     /*changeManagerNameHandler= (event)=>{
         this.setState({managerName: event.target.value});
     }

     changeEmailHandler= (event)=>{
        this.setState({email: event.target.value});
    }

    changeMobileNoHandler= (event)=>{
        this.setState({mobileNo: event.target.value});
    }*/

    changeNoOfStocksHandler=(event)=>{
        this.setState({noOfStocks: event.target.value});
    }

    changeStockPriceHandler=(event)=>{
        this.setState({stockPrice: event.target.value});
    }

    changePercentageChangeHandler=(event)=>{
        this.setState({percentageChange: event.target.value});
    }

     saveCompany =(e) =>{
         e.preventDefault();
         let company ={companyName:this.state.companyName,
                       /*managerName: this.state.managerName,
                       email:this.state.email,
                       mobileNo:this.state.mobileNo,*/
                       noOfStocks:this.state.noOfStocks,
                       stockPrice:this.state.stockPrice,
                       percentageChange:this.state.percentageChange
                    };
         console.log('company => '+JSON.stringify(company));
         CompanyService.addCompanyInfo(company).then(res =>{
             this.props.history.push('/companies');

         });
     }
     
     cancel(){
        this.props.history.push('/companies');
     }

    render() {
        return (
            <div>
                <div className="container">
                    <div className="row">
                        <div className="card col-md-6 offset-md-3 offset=md-3"></div>
                        <h2 className="text-center">Add Company</h2>
                        <div className="card-body">
                            <form>
                                <div className="form-group">
                                    <label>Company Name</label>
                                    <input placeholder="Company Name" name="companyName" className="form-control"
                                    value={this.state.companyName} onChange={this.changeCompanyNameHandler}></input>
                                </div>
                                {/*<div className="form-group">
                                    <label>Manager Name</label>
                                    <input placeholder="Manager Name" name="managerName" className="form-control"
                                    value={this.state.managerName} onChange={this.changeManagerNameHandler}></input>
                                </div>
                                <div className="form-group">
                                    <label>Email</label>
                                    <input placeholder="Email" name="email" className="form-control"
                                    value={this.state.email} onChange={this.changeEmailHandler}></input>
                                </div>
                                <div className="form-group">
                                    <label>Mobile No</label>
                                    <input placeholder="Mobile No" name="mobileNo" className="form-control"
                                    value={this.state.mobileNo} onChange={this.changeMobileNoHandler}></input>
                                </div>*/}
                                <div className="form-group">
                                    <label>No Of Stocks</label>
                                    <input placeholder="No Of Stocks" name="noOfStocks" className="form-control"
                                    value={this.state.noOfStocks} onChange={this.changeNoOfStocksHandler}></input>
                                </div>
                                <div className="form-group">
                                    <label>Stock Price</label>
                                    <input placeholder="Stock Price" name="stockPrice" className="form-control"
                                    value={this.state.stockPrice} onChange={this.changeStockPriceHandler}></input>
                                </div>
                                <div className="form-group">
                                    <label>Percentage Change</label>
                                    <input placeholder="Percentage Change" name="percentageChange" className="form-control"
                                    value={this.state.percentageChange} onChange={this.changePercentageChangeHandler}></input>
                                </div>
                                <button className="btn btn-success" onClick={this.saveCompany}>Save</button>
                                <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft: "10px"}}>Cancel</button>
                            </form>
                        </div>
                    </div>
                    
                </div>
                
            </div>
        )
    }
}
export default AddCompanyComponent