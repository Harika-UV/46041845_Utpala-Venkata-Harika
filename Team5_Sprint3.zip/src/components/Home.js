import React from 'react';
// import './About.css';
// import { Link } from 'react-router-dom';

function Home() {
  return (
    <div>
      <h1 className="home">HOME PAGE</h1>
      <div>
        {/* <img src={"./login.svg"} className="img-responsive" alt="Logo"/> */}
        <h3 className="text">Here, you can exchange stocks and become an investor.</h3>
      </div>
    </div>
  );
}

export default Home;
