import React, { Component } from 'react'
import StockService from '../services/StockService'

 class ViewStockComponent extends Component {
     constructor(props)
     {
         super(props)
         this.state={
             stockId: this.props.match.params.stockId,
             stock:{}
        }
     }
     componentDidMount()
     {
    StockService.viewStockDetails(this.state.stockId).then(res =>{
        
            this.setState({stock: res.data})
         });
     }
    render() {
        return (
            <div>
                <br></br>
                <div className="card col-md-6 offset-md-3">
                    <h3 className= "text-center"> View Stock Details</h3>
                    <div className="card-body">
                        <div className="row">
                            <label>Stock Name : </label>
                            <div>{this.state.stock.stockName}</div>
                        </div>
                        <div className="row">
                            <label>Quantity: </label>
                            <div>{this.state.stock.quantity}</div>
                        </div>
                        <div className="row">
                            <label>Avg Price: </label>
                            <div>{this.state.stock.avgPrice}</div>
                        </div>
                        <div className="row">
                            <label>Type: </label>
                            <div>{this.state.stock.type}</div>
                        </div>
                        <div className="row">
                            <label>TotalNoOfStocks: </label>
                            <div>{this.state.stock.totalNoOfStocks}</div>
                        </div>
                        <div className="row">
                            <label>ProfitLoss: </label>
                            <div>{this.state.stock.profitLoss}</div>
                        </div>
                        <div className="row">
                            <label>Status: </label>
                            <div>{this.state.stock.status}</div>
                        </div>
                        </div> 
                </div>
            </div>
        )
    }
}
export default ViewStockComponent