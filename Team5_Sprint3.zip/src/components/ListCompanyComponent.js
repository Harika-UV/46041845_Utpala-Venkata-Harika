import React, { Component } from 'react'
import CompanyService from '../services/CompanyService'

 class ListCompanyComponent extends Component {
     constructor(props)
     {
         super(props)
         this.state={
             companies: []
         }
         this.addCompany=this.addCompany.bind(this);
         this.viewCompany=this.viewCompany.bind(this);
         this.editCompany=this.editCompany.bind(this);
         this.deleteCompany=this.deleteCompany.bind(this);
     }

     componentDidMount(){
        CompanyService.getAllCompanyInfo().then((res) =>
         {
             this.setState({companies: res.data})
         });
     }

     addCompany(){
         this.props.history.push('/add-company');
     }

     deleteCompany(companyId){
        CompanyService.deleteCompanyInfo(companyId).then(res =>
            {
                this.setState({companies: this.state.companies.filter(company =>company.companyId !== companyId)})
            }
        );
    }

     viewCompany(companyId){
         this.props.history.push(`/view-company/${companyId}`);
     }
     
    
     editCompany(companyId)
     {
         this.props.history.push(`/edit-company/${companyId}`)
     }

    render() {
        return (
            <div>
                <h2 className="text-center">Companies List</h2>
                <div className="row">
                    <button className="btn btn-primary" onClick={this.addCompany}>Add Company</button>
                </div>
                <div className="row">
                    <table className="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>Company ID</th>
                                <th>Company Name</th>
                                {/*<th>Manager Name</th>
                                <th>Manager Email</th>
                                <th>Manager Mobile No</th>*/}
                                <th>No of Stocks</th>
                                <th>Stock Price</th>
                                <th>Percentage Change</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                this.state.companies.map(
                                    company =>
                                    <tr key= {company.companyId}>
                                        <td>{company.companyId}</td>
                                        <td>{company.companyName}</td>
                                        {/*<td>{company.manager.managerName}</td>
                                        <td>{company.manager.email}</td>
                                        <td>{company.manager.mobileNo}</td>*/}
                                        <td>{company.noOfStocks}</td>
                                        <td>{company.stockPrice}</td>
                                        <td>{company.percentageChange}</td>
                                        <td>
                                            <button onClick={() => this.editCompany(company.companyId)} className="btn btn-info">Update</button>
                                            <button style={{marginLeft: "10px"}} onClick={() => this.deleteCompany(company.companyId)} className="btn btn-danger">Delete</button>
                                            <button style={{marginLeft: "10px"}} onClick={() => this.viewCompany(company.companyId)} className="btn btn-info">View</button>
                                            
                                        </td>

                                    </tr>
                                )
                            }
                        </tbody>

                    </table>

                </div>
            </div>
        )
    }
}
export default ListCompanyComponent;