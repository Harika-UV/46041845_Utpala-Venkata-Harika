import React, { Component } from 'react'
import AdminService from '../services/AdminService';

class ListAdminComponent extends Component {
    constructor(props)
    {
        super(props)
        this.state={
            admins: []
        }
        this.addAdmin=this.addAdmin.bind(this);
        this.editAdmin=this.editAdmin.bind(this);
        this.deleteAdmin=this.deleteAdmin.bind(this);
    }
    deleteAdmin(id)
    {
        AdminService.deleteAdmin(id).then(res =>
           {
               this.setState({admins: this.state.admins.filter(admin =>admin.id !== id)})

           });

    }
    viewAdmin(id)
    {
        this.props.history.push(`/view-admin/${id}`);
    }
     componentDidMount()
     {
        AdminService.getAllAdmin().then((res) =>
         {
           this.setState({admins: res.data})

       });
     }
    addAdmin()
    {
        this.props.history.push('/add-admin/');
    }
    editAdmin(id)
    {
        this.props.history.push(`/update-admin/${id}`)
    }
   render() {
       return (
           <div>
               <h2 className="text-center">AdminList</h2>
               <div className="row">
                   <button className="btn btn-primary" onClick={this.addAdmin}>Add Admin</button>
               </div>
               <div className="row">
                   <table className="table table-striped table-bordered">
                       <thead>
                           <tr>
                 
                               <th>AdminName</th>
                               <th>Email</th>
                               <th>AdminPassword</th>
                               <th>Actions</th>
                           </tr>
                       </thead>
                       <tbody>
                           {
                               this.state.admins.map(
                                   admin =>
                                   <tr key= {admin.id}>
                                       <td>{admin.adminName}</td>
                                       <td>{admin.email}</td>
                                       <td>{admin.adminPassword}</td>
                                       <td>
                                           <button onClick={() => this.editAdmin(admin.id)} className="btn btn-info">Update</button>
                                           <button style={{marginLeft: "10px"}} onClick={() => this.deleteAdmin(admin.id)} className="btn btn-danger">Delete</button>
                                           <button style={{marginLeft: "10px"}} onClick={() => this.viewAdmin(admin.id)} className="btn btn-info">View</button>
                                           
                                       </td>

                                   </tr>
                               )
                           }
                       </tbody>

                   </table>

               </div>
           </div>
       )
   }
}
export default ListAdminComponent