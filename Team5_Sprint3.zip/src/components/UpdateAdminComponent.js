import React, { Component } from 'react'
import AdminService from '../services/AdminService';

class UpdateAdminComponent extends Component {
    constructor(props)
    {
        super(props)
        this.state={
            id: this.props.match.params.id,
            adminName:'',
            email:'',
            adminPassword:''

            
        }
        this.changeAdminNameHandler=this.changeAdminNameHandler.bind(this);
        this.changeEmailHandler=this.changeEmailHandler.bind(this);
        this.changeAdminPasswordHandler=this.changeAdminPasswordHandler.bind(this);
        this.updateAdmin=this.updateAdmin.bind(this);
    }
    
    componentDidMount()
    {
        AdminService.getAdminById(this.state.id).then((res) =>{
            let admin = res.data;
            this.setState({adminName: admin.adminName,email:admin.email,
                adminPassword: admin.adminPassword
            });
        });
    }
    
    changeAdminNameHandler= (event)=>
    {
        this.setState({adminName: event.target.value});
    }

    changeEmailHandler= (event)=>
    {
        this.setState({email: event.target.value});
    }
    
    changeAdminPasswordHandler= (event)=>
    {
        this.setState({adminPassword: event.target.value});
    }
    updateAdmin =(e) =>{
        e.preventDefault();
        let admin ={id:this.state.id,adminName: this.state.adminName,email:this.state.email,adminPassword: this.state.adminPassword};
            console.log('admin => '+JSON.stringify(admin));
            AdminService.updateAdmin(admin,this.state.id).then(res =>{
                
                this.props.history.push('/admins');
   

        });
        
    }
    cancel()
    {
       this.props.history.push('/admins');
    }
   render() {
       return (
           <div>
               <div className="container">
                   <div className="row">
                       <div className="card col-md-6 offset-md-3 offset=md-3"></div>
                       <h3 className="text-center">Update Admin</h3>
                       <div className="card-body">
                           <form>
                           
                           <div className="form-group">
                                    <label>Admin Name:</label>
                                    <input placeholder="Admin Name" name="adminName" className="form-control"
                                    value={this.state.adminName} onChange={this.changeAdminNameHandler}></input>
                                </div>
                                <div className="form-group">
                                    <label>Email ID:</label>
                                    <input placeholder="Email" name="email" className="form-control"
                                    value={this.state.email} onChange={this.changeEmailHandler}></input>
                                </div>
                                <div className="form-group">
                                    <label>Admin Password:</label>
                                    <input type="password" placeholder="Admin Password" name="adminPassword" className="form-control"
                                    value={this.state.adminPassword} onChange={this.changeAdminPasswordHandler}></input>
                                </div>
                               <button className="btn btn-success" onClick={this.updateAdmin}>Save</button>
                               <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft: "10px"}}>Cancel</button>
                           </form>
                       </div>
                   </div>
                   
               </div>
               
           </div>
       )
   }
}

export default UpdateAdminComponent