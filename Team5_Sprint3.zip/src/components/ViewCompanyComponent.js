import React, { Component } from 'react'
import CompanyService from '../services/CompanyService'

 class ViewCompanyComponent extends Component {
     constructor(props)
     {
         super(props)
         this.state={
             companyId: this.props.match.params.companyId,
             company:[]
            //  company:{
            //      manager:{}
            //  }

        }
     }

     componentDidMount()
     {
         CompanyService.getCompanyDetails(this.state.companyId).then(res =>{
            this.setState({company: res.data})
         });
     }

    render() {
        return (
            <div>
                <div className="card col-md-6 offset-md-3">
                    <h3 className= "text-center"> View Company Details</h3>
                    <div className="card-body">
                    <div className="row">
                            <label>Company ID:  </label>
                            <div>{this.state.company.companyId}</div>
                        </div>
                        <div className="row">
                            <label>Company Name:  </label>
                            <div>{this.state.company.companyName}</div>
                        </div>
                        {/*<div className="row">
                            <label>Manager Name:  </label>
                            <div>{this.state.company.manager.managerName}</div>
                        </div>
                        <div className="row">
                            <label>Manager Email:  </label>
                            <div>{this.state.company.manager.email}</div>
                        </div>
                        <div className="row">
                            <label>Manager Mobile No:  </label>
                        <div>{this.state.company.manager.mobileNo}</div>
                        </div>*/}
                        <div className="row">
                            <label>No Of Stocks:  </label>
                            <div>{this.state.company.noOfStocks}</div>
                        </div>
                        <div className="row">
                            <label>Stock Price:  </label>
                            <div>{this.state.company.stockPrice}</div>
                        </div>
                        <div className="row">
                            <label>Percentage Change:  </label>
                            <div>{this.state.company.percentageChange}</div>
                        </div>
                        </div> 
                </div>
            </div>
        )
    }
}
export default ViewCompanyComponent