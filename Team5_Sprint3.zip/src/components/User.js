import React from 'react';
// import './About.css';
import { Link } from 'react-router-dom';

function User() {
  return (
    <div>
      <h1>User</h1>
      <h2>User Module</h2>
        {/* <ul>
          <Link to={"/users"}><li>ListUserComponent</li></Link>
        </ul> */}
    </div>
  );
}

export default User;