import React from 'react';
// import'./App.css';
// import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import './Login.css';
// import Select from 'react-select';
function Login() {

  // const options = [
  //   { value: 'admin', label: 'Admin' },
  //   { value: 'investor', label: 'Investor' },
  //   { value: 'manager', label: 'Manager' }
  // ]
  
  // const MyComponent = () => (
  //   <Select options={options} />
  // )
  return (
    <div>
      {/* <h>Login Page</h3> */}
      <div class="container">
      <div class="forms-container">
        <div class="signin-signup"></div>
          <form action="#" className="sign-in-form">
                <h2 className="title">Log in</h2>
                <div className="input-field">
                  <i className="fas fa-user"></i>
                  {/* <FontAwesomeIcon icon={['fas', 'user']} /> */}
                  <input type="text" placeholder="Username" />
                </div>
                <div className="input-field">
                  <i class="fas fa-lock"></i>
                  <input type="password" placeholder="Password" />
                </div>
                 {/* <div className="input-field"> 
                  <select value="role" type="radio" placeholder="Select role">    
                    <option value="Admin">Admin</option>
                    <option value="Investor">Investor</option>
                    <option value="Manager">Manager</option>
                  </select>
                  <Select className="selectRole" options={options} />
                 </div>  */}
                
                <input type="submit" className="btn solid" value="Login" />
          </form>
        </div>
      </div>
    </div>
  );
}

export default Login;
