import React from 'react';
// import './About.css';
import { Link } from 'react-router-dom';

function Modules() {
  return (
    <div>
      <h1>Modules</h1>
      <h2>User Module</h2>
        <ul>
          <Link to={"/users"}><li>User</li></Link>
        </ul>
        <h2>Admin Module</h2>
        <ul>
          <Link to={"/admins"}><li>Admin</li></Link>
        </ul>
        <h2>Company Module</h2>
        <ul>
          <Link to={"/companies"}><li>Company</li></Link>
        </ul>
        <h2>Manager Module</h2>
        <ul>
          <Link to={"/managers"}><li>Manager</li></Link>
        </ul>
        <h2>Investor Module</h2>
        <ul>
          <Link to={"/investors"}><li>Investor</li></Link>
        </ul>
        <h2>Stock Module</h2>
        <ul>
          <Link to={"/stocks"}><li>Stock</li></Link>
        </ul>
    </div>
  );
}

export default Modules;