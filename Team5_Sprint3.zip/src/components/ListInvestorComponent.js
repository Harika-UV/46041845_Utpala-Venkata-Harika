import React, { Component } from 'react'
import InvestorService from '../services/InvestorService'

 class ListInvestorComponent extends Component {
     constructor(props)
     {
         super(props)
         this.state={
             investors: []
         }
         this.addInvestor=this.addInvestor.bind(this);
         this.viewInvestor=this.viewInvestor.bind(this);
         this.editInvestor=this.editInvestor.bind(this);
         this.deleteInvestor=this.deleteInvestor.bind(this);
     }

     componentDidMount(){
        InvestorService.getAllInvestors().then((res) =>
         {
             this.setState({investors: res.data})
         });
     }

     addInvestor(){
         this.props.history.push('/add-investor');
     }

     deleteInvestor(investorId){
        InvestorService.deleteInvestor(investorId).then(res =>
            {
                this.setState({investors: this.state.investors.filter(investor =>investor.investorId !== investorId)})
            }
        );
    }

     viewInvestor(investorId){
         this.props.history.push(`/view-investor/${investorId}`);
     }
     
    
     editInvestor(investorId)
     {
         this.props.history.push(`/edit-investor/${investorId}`)
     }

    render() {
        return (
            <div>
                <h2 className="text-center">Investors List</h2>
                <div className="row">
                    <button className="btn btn-primary" onClick={this.addInvestor}>Add Investor</button>
                </div>
                <div className="row">
                    <table className="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>Investor ID</th>
                                <th>Investor Name</th>
                                <th>Email</th>
                                <th>Mobile No</th>
                                <th>Password</th>
                                <th>Gender</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                this.state.investors.map(
                                    investor =>
                                    <tr key= {investor.investorId}>
                                        <td>{investor.investorId}</td>
                                        <td>{investor.investorName}</td>
                                        <td>{investor.email}</td>
                                        <td>{investor.mobileNo}</td>
                                        <td>{investor.password}</td>
                                        <td>{investor.gender}</td>
                                        <td>
                                            <button onClick={() => this.editInvestor(investor.investorId)} className="btn btn-info">Update</button>
                                            <button style={{marginLeft: "10px"}} onClick={() => this.deleteInvestor(investor.investorId)} className="btn btn-danger">Delete</button>
                                            <button style={{marginLeft: "10px"}} onClick={() => this.viewInvestor(investor.investorId)} className="btn btn-info">View</button>
                                            
                                        </td>

                                    </tr>
                                )
                            }
                        </tbody>

                    </table>

                </div>
            </div>
        )
    }
}
export default ListInvestorComponent;