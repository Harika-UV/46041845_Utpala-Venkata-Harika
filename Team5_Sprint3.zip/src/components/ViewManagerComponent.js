import React, { Component } from 'react'
import ManagerService from '../services/ManagerService'

 class ViewManagerComponent extends Component {
     constructor(props)
     {
         super(props)
         this.state={
             managerId: this.props.match.params.managerId,
             manager:{}
        }
     }

     componentDidMount()
     {
         ManagerService.getManagerDetails(this.state.managerId).then(res =>{
            this.setState({manager: res.data})
         });
     }

    render() {
        return (
            <div>
                <div className="card col-md-6 offset-md-3">
                    <h3 className= "text-center"> View Manager Details</h3>
                    <div className="card-body">
                    <div className="row">
                            <label>Manager Id:  </label>
                            <div>{this.state.manager.managerId}</div>
                        </div>
                        <div className="row">
                            <label>Manager Name:  </label>
                            <div>{this.state.manager.managerName}</div>
                        </div>
                        <div className="row">
                            <label>Manager Email:  </label>
                            <div>{this.state.manager.email}</div>
                        </div>
                        <div className="row">
                            <label>Manager Mobile No:  </label>
                            <div>{this.state.manager.mobileNo}</div>
                        </div>
                        </div> 
                </div>
            </div>
        )
    }
}
export default ViewManagerComponent