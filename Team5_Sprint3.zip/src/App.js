import './App.css';
import About from './components/About';
import Login from './components/Login';
import Signup from './components/Signup';
import Nav from './components/Nav';
import Home from './components/Home';

import {BrowserRouter as Router, Switch, Route} from 'react-router-dom';
import Modules from './components/Modules';

import AddUserComponent from './components/AddUserComponent';
import ListUserComponent from './components/ListUserComponent';
import UpdateUserComponent from './components/UpdateUserComponent';
import ViewUserComponent from './components/ViewUserComponent';

import User from './components/User';

import CreateAdminComponent from './components/CreateAdminComponent';
import ListAdminComponent from './components/ListAdminComponent';
import UpdateAdminComponent from './components/UpdateAdminComponent';
import ViewAdminComponent from './components/ViewAdminComponent';

import AddCompanyComponent from './components/AddCompanyComponent';
import ListCompanyComponent from './components/ListCompanyComponent';
import UpdateCompanyComponent from './components/UpdateCompanyComponent';
import ViewCompanyComponent from './components/ViewCompanyComponent';

import AddManagerComponent from './components/AddManagerComponent';
import ListManagerComponent from './components/ListManagerComponent';
import UpdateManagerComponent from './components/UpdateManagerComponent';
import ViewManagerComponent from './components/ViewManagerComponent';

import AddInvestorComponent from './components/AddInvestorComponent';
import ListInvestorComponent from './components/ListInvestorComponent';
import UpdateInvestorComponent from './components/UpdateInvestorComponent';
import ViewInvestorComponent from './components/ViewInvestorComponent';

import AddStockComponent from './components/AddStockComponent';
import ListStockComponent from './components/ListStockComponent';
import UpdateStockComponent from './components/UpdateStockComponent';
import ViewStockComponent from './components/ViewStockComponent';

function App() {
  return (
    <Router>
      <div className="App">
        <Nav />
        <Switch>
          <Route path="/" exact component={Home} />
          <Route path="/about" component={About} />
          <Route path="/login" component={Login} />
          <Route path="/signup" component={Signup} />
          <Route path="/modules" component={Modules} />
          <Route path="/user" component={User} />

          {/* <Route path="" component={DropDown} /> */}
          <Route path="/users" component={ListUserComponent} />
          <Route path="/add-user" component={AddUserComponent} />
          <Route path="/edit-user/:id" component={UpdateUserComponent} />
          <Route path="/view-user/:id" component={ViewUserComponent} />

          <Route path="/admins" component={ListAdminComponent} />
          <Route path="/add-admin" component={CreateAdminComponent} />
          <Route path="/edit-admin/:id" component={UpdateAdminComponent} />
          <Route path="/view-admin/:id" component={ViewAdminComponent} />

          <Route path="/companies" component={ListCompanyComponent} />
          <Route path="/add-company" component={AddCompanyComponent} />
          <Route path="/edit-company/:companyId" component={UpdateCompanyComponent} />
          <Route path="/view-company/:companyId" component={ViewCompanyComponent} />

          <Route path="/managers" component={ListManagerComponent} />
          <Route path="/add-manager" component={AddManagerComponent} />
          <Route path="/edit-manager/:managerId" component={UpdateManagerComponent} />
          <Route path="/view-manager/:managerId" component={ViewManagerComponent} />

          <Route path = "/investors" component = {ListInvestorComponent}></Route>
          <Route path = "/add-investor" component = {AddInvestorComponent}></Route>
          <Route path = "/view-investor/:investorId" component = {ViewInvestorComponent}></Route>
          <Route path = "/edit-investor/:investorId" component = {UpdateInvestorComponent}></Route>

          <Route path="/stocks" component={ListStockComponent}></Route>
          <Route path="/add-stock" component={AddStockComponent}></Route>
          <Route path="/view-stock/:stockId" component={ViewStockComponent}></Route>
          <Route path="/edit-stock/:stockId" component={UpdateStockComponent}></Route>
          {/* <Route path="/user-c" component={User} /> */}
        </Switch>
      </div>
    </Router>
  );
}

export default App;


