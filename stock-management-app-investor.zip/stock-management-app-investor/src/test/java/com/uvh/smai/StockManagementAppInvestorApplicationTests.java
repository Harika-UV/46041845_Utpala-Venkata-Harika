package com.uvh.smai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockManagementAppInvestorApplicationTests {

	@Test
	void contextLoads() {
	}

}
