package com.uvh.smai.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Entity
public class Investor {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "investor_id")
	private String investorId;
	
	@NotNull
	@Column(name = "investor_name")
	private String investorName;
	
	@Email
	private String email;
	
	@Pattern(regexp = "(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)[a-zA-Z\\d]{8,}", message = "Please enter correct password.")
	private String password;
	
	@Pattern(regexp = "([6-9]{1}[0-9]{9}", message = "Please enter valid mobile number.")
	@Column(name= "mobile_no")
	private String mobileNo;
	
	private String gender;
	private BankAccount account;
	
	
	public Investor() {
		super();
	}
	public Investor(String investorName, String email, String password, String mobileNo, String gender,
			BankAccount account) {
		super();
		this.investorName = investorName;
		this.email = email;
		this.password = password;
		this.mobileNo = mobileNo;
		this.gender = gender;
		this.account = account;
	}
	
	public String getInvestorId() {
		return investorId;
	}
	public void setInvestorId(String investorId) {
		this.investorId = investorId;
	}
	public String getInvestorName() {
		return investorName;
	}
	public void setInvestorName(String investorName) {
		this.investorName = investorName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public BankAccount getAccount() {
		return account;
	}
	public void setAccount(BankAccount account) {
		this.account = account;
	}
	
	@Override
	public String toString() {
		return "Investor [investorId=" + investorId + ", investorName=" + investorName + ", email=" + email
				+ ", password=" + password + ", mobileNo=" + mobileNo + ", gender=" + gender + ", account=" + account
				+ "]";
	}	
	
}
