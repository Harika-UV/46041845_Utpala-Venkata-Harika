package com.uvh.smai.controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.uvh.smai.exceptions.ResourceNotFoundException;
import com.uvh.smai.models.Investor;
import com.uvh.smai.repositories.InvestorRepository;

@RestController
@RequestMapping
public class InvestorController {

	@Autowired
	private InvestorRepository investorRepository;
	
	@GetMapping("investors")
	public List<Investor> getAllInvestors() {
		return this.investorRepository.findAll();	
	}
	
	@GetMapping("/investors/{id}")
	public ResponseEntity<Investor> getInvestorDetails(@PathVariable(value = "id") Integer investorId) 
			throws ResourceNotFoundException {
		Investor investor = investorRepository.findById(investorId)
				.orElseThrow(() -> new ResourceNotFoundException("Employee not found for this id :: " + investorId));
		return ResponseEntity.ok().body(investor);
	}
	
	@PostMapping("investors")
	public Investor addInvestor(@RequestBody Investor investor) {
		return this.investorRepository.save(investor);
	}
	
	@PutMapping("investors/{id}")
	public ResponseEntity<Investor> updateInvestor(@PathVariable(value = "id") Integer investorId, 
			@Valid @RequestBody Investor investorDetails) throws ResourceNotFoundException {
		Investor investor = investorRepository.findById(investorId)
				.orElseThrow(() -> new ResourceNotFoundException("Employee not found for this id :: " + investorId));
		investor.setInvestorName(investorDetails.getInvestorName());
		investor.setEmail(investorDetails.getEmail());
		investor.setMobileNo(investorDetails.getMobileNo());
		investor.setGender(investorDetails.getGender());
		
		return ResponseEntity.ok(this.investorRepository.save(investor));
	}
	
	@DeleteMapping("investors/{id}")
	public Map<String, Boolean> deleteInvestor(@PathVariable(value = "id") Integer investorId) throws ResourceNotFoundException {
		Investor investor = investorRepository.findById(investorId)
				.orElseThrow(() -> new ResourceNotFoundException("Employee not found for this id :: " + investorId));
		this.investorRepository.delete(investor);
		
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		
		return response;
	}
}

